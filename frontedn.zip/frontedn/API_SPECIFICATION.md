# API Specification - LeadGen AI

## Leads

### Search Leads
- **Endpoint**: `GET /leads/search`
- **Query Params**:
  - `industry`: string (optional)
  - `location`: string (optional)
  - `targetRole`: string (optional)
  - `limit`: number (default: 25)
  - `sortBy`: string ('leadScore', 'growthPotential', 'companyName', 'conversionProbability')
  - `sortOrder`: string ('asc', 'desc')
- **Response**: `200 OK`
  ```json
  [
    {
      "id": "number",
      "companyName": "string",
      "industry": "string",
      "website": "string",
      "location": "string",
      "leadScore": "number",
      "conversionProbability": "number",
      "growthPotential": "string", // 'High', 'Moderate', 'Steady'
      "description": "string",
      "companySize": "string",
      "targetRole": "string",
      "contactPerson": "string",
      "isSaved": "boolean",
      "aiInsights": {
        "whyGoodTarget": "string",
        "painPoints": "string",
        "outreachAngle": "string",
        "dealPotential": "string"
      },
      "outreachRecommendation": {
        "strategy": "string",
        "bestDay": "string",
        "bestChannel": "string"
      }
    }
  ]
  ```

### Get Dashboard Stats
- **Endpoint**: `GET /leads/stats`
- **Response**: `200 OK`
  ```json
  {
    "totalLeads": "number",
    "avgLeadScore": "number",
    "savedLeads": "number",
    "aiMessagesGenerated": "number",
    "probabilityDistribution": {
      "high": "number",
      "medium": "number",
      "low": "number"
    },
    "aiInsights": {
      "bestIndustry": "string",
      "topScoringLead": "string",
      "recommendedTime": "string"
    }
  }
  ```

### Enrich Lead
- **Endpoint**: `GET /leads/:id/enrich`
- **Response**: `200 OK`
  ```json
  {
    "id": "number",
    "companyName": "string",
    "description": "string",
    "industry": "string",
    "companySize": "string",
    "website": "string",
    "targetRoleContact": "string",
    "growthPotential": "string"
  }
  ```

### Save Lead
- **Endpoint**: `POST /leads/:id/save`
- **Response**: `200 OK`
  ```json
  { "message": "Lead saved successfully" }
  ```

### Unsave Lead
- **Endpoint**: `DELETE /leads/:id/save`
- **Response**: `200 OK`
  ```json
  { "message": "Lead unsaved successfully" }
  ```

### Get Saved Leads
- **Endpoint**: `GET /leads/saved`
- **Response**: `200 OK`
  ```json
  [
    {
      "id": "number",
      "companyName": "string",
      "industry": "string",
      "website": "string",
      "leadScore": "number",
      "isSaved": "boolean"
    }
  ]
  ```

## AI

### Generate Outreach Message
- **Endpoint**: `POST /ai/generate-outreach`
- **Request Body**:
  ```json
  {
    "companyName": "string",
    "industry": "string",
    "targetRole": "string"
  }
  ```
- **Response**: `200 OK`
  ```json
  {
    "subject": "string",
    "body": "string"
  }
  ```

### Analyze Lead (AI Assistant)
- **Endpoint**: `POST /ai/analyze`
- **Request Body**:
  ```json
  {
    "companyName": "string",
    "industry": "string",
    "description": "string",
    "targetRole": "string"
  }
  ```
- **Response**: `200 OK`
  ```json
  {
    "insights": "string",
    "outreachStrategy": "string",
    "talkingPoints": ["string"],
    "pitchAngle": "string"
  }
  ```

### Chat with Assistant
- **Endpoint**: `POST /ai/chat`
- **Request Body**:
  ```json
  {
    "messages": [
      { "role": "user", "content": "string" }
    ],
    "context": {
      "companyName": "string",
      "industry": "string"
    }
  }
  ```
- **Response**: `200 OK (Streamed or text)`
  ```json
  {
    "message": "string"
  }
  ```