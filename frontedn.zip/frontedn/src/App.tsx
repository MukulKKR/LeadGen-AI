import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  Users, 
  Search, 
  Save, 
  History, 
  Settings, 
  LayoutDashboard, 
  Target,
  Sparkles,
  Zap,
  CheckCircle2,
  TrendingUp,
  BarChart3,
  X,
  ArrowRight,
  Flame,
  Star,
  Plus,
  MessageSquare,
  ChevronRight,
  BarChart4,
  Clock,
  Briefcase,
  Building2,
  MapPin,
  Brain,
  Info,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence, useMotionValue, useSpring, useTransform, animate } from 'framer-motion';
import { useInfiniteQuery, useQueryClient } from '@tanstack/react-query';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import SearchForm from './components/SearchForm';
import LeadTable from './components/LeadTable';
import AISalesAssistant from './components/AISalesAssistant';
import AIOutreachGenerator from './components/AIOutreachGenerator';
import EnrichmentPanel from './components/EnrichmentPanel';
import AnalyticsView from './components/AnalyticsView';
import SettingsView from './components/SettingsView';
import CampaignView from './components/CampaignView';
import HistoryView from './components/HistoryView';
import ApiKeyView from './components/ApiKeyView';
import { Lead, leadService, DashboardStats } from './services/leadService';
import { PixelTrail } from './components/ui/pixel-trail';
import { useScreenSize } from './components/hooks/use-screen-size';
import { Skeleton } from './components/ui/Skeleton';
import { Tooltip } from './components/ui/Tooltip';
import { Toaster, toast } from 'sonner';

// Improved animated counter component for metrics
const AnimatedCounter = ({ value, duration = 1.5 }: { value: number, duration?: number }) => {
  const count = useMotionValue(0);
  const rounded = useTransform(count, (latest) => Math.round(latest).toLocaleString());
  
  useEffect(() => {
    const controls = animate(count, value, { duration: duration, ease: "easeOut" });
    return controls.stop;
  }, [value, count, duration]);

  return <motion.span>{rounded}</motion.span>;
};

function App() {
  const [searchQuery, setSearchQuery] = useState({ industry: '', location: '', role: '' });
  const screenSize = useScreenSize();
  const [savedLeads, setSavedLeads] = useState<Lead[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'search' | 'saved' | 'analytics' | 'campaigns' | 'history' | 'settings' | 'api'>('search');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [drawerMode, setDrawerMode] = useState<'enrich' | 'outreach'>('enrich');
  const [isFabOpen, setIsFabOpen] = useState(false);
  const queryClient = useQueryClient();

  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    status,
    isLoading: isQueryLoading,
    isFetching
  } = useInfiniteQuery<Lead[], Error, any, (string | typeof searchQuery)[]>({
    queryKey: ['leads', searchQuery],
    queryFn: ({ pageParam, signal }) => 
      leadService.searchLeads({ ...searchQuery, page: pageParam as number, limit: 20 }, signal),
    initialPageParam: 1,
    getNextPageParam: (lastPage: Lead[], allPages: Lead[][]) => {
      return lastPage.length === 20 ? allPages.length + 1 : undefined;
    },
    enabled: hasSearched && (activeTab === 'search' || activeTab === 'dashboard'),
    staleTime: 1000 * 60 * 5, // Cache for 5 minutes
  });

  const leads = useMemo(() => {
    return data?.pages.flat() || [];
  }, [data]);

  const isLoading = isQueryLoading || (isFetching && !isFetchingNextPage && leads.length === 0);

  useEffect(() => {
    fetchSavedLeads();
  }, []);

  useEffect(() => {
    if (hasSearched || activeTab === 'saved') {
      const currentLeads = activeTab === 'saved' ? savedLeads : leads;
      const calculatedStats = calculateStats(currentLeads);
      setStats(calculatedStats);
    } else {
      setStats({
        totalLeads: 0,
        avgLeadScore: 0,
        savedLeads: 0,
        aiMessagesGenerated: 0,
        probabilityDistribution: { high: 0, medium: 0, low: 0 },
        aiInsights: {
          bestIndustry: '—',
          topScoringLead: '—',
          recommendedTime: '—'
        }
      });
    }
  }, [leads, savedLeads, hasSearched, activeTab]);

  const calculateStats = (leadsList: Lead[]): DashboardStats => {
    const totalLeads = leadsList.length;
    const avgLeadScore = totalLeads > 0 
      ? Math.round(leadsList.reduce((sum, l: Lead) => sum + l.leadScore, 0) / totalLeads) 
      : 0;
    const savedLeadsInContext = leadsList.filter((l: Lead) => l.isSaved).length;
    
    const aiMessagesGenerated = totalLeads * 2;

    const high = leadsList.filter((l: Lead) => l.conversionProbability >= 70).length;
    const medium = leadsList.filter((l: Lead) => l.conversionProbability >= 40 && l.conversionProbability < 70).length;
    const low = leadsList.filter((l: Lead) => l.conversionProbability < 40).length;

    let bestIndustry = '—';
    let topScoringLead = '—';
    let recommendedTime = '—';

    if (totalLeads > 0) {
      const industries = leadsList.map((l: Lead) => l.industry);
      const counts = industries.reduce((acc, curr) => {
        acc[curr] = (acc[curr] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      bestIndustry = Object.keys(counts).reduce((a, b) => counts[a] > counts[b] ? a : b);
      
      topScoringLead = [...leadsList].sort((a, b) => b.leadScore - a.leadScore)[0].companyName;
      recommendedTime = 'Tuesday at 10:00 AM';
    }

    return {
      totalLeads,
      avgLeadScore,
      savedLeads: activeTab === 'saved' ? savedLeads.length : savedLeadsInContext,
      aiMessagesGenerated,
      probabilityDistribution: { high, medium, low },
      aiInsights: {
        bestIndustry,
        topScoringLead,
        recommendedTime
      }
    };
  };

  const fetchSavedLeads = async () => {
    try {
      const data = await leadService.getSavedLeads();
      setSavedLeads(data);
    } catch (error) {
      console.error('Failed to fetch saved leads:', error);
    }
  };

  const handleSearch = useCallback((query: { industry: string; location: string; role: string }) => {
    setSearchQuery(query);
    setHasSearched(true);
    setActiveTab('search');
    toast.success('AI is discovering new leads for you...');
  }, []);

  const handleSelectLead = (lead: Lead, mode: 'enrich' | 'outreach' = 'enrich') => {
    setSelectedLead(lead);
    setDrawerMode(mode);
    setIsDrawerOpen(true);
  };

  const handleSaveLead = async (id: number) => {
    try {
      await leadService.saveLead(id);
      // Invalidate queries to reflect changes if needed, or update locally
      queryClient.setQueryData(['leads', searchQuery], (oldData: any) => {
        if (!oldData) return oldData;
        return {
          ...oldData,
          pages: oldData.pages.map((page: Lead[]) => 
            page.map(l => l.id === id ? { ...l, isSaved: true } : l)
          )
        };
      });
      if (selectedLead?.id === id) setSelectedLead({ ...selectedLead, isSaved: true });
      fetchSavedLeads();
      toast.success('Lead saved to your prospects!');
    } catch (error) {
      console.error('Failed to save lead:', error);
      toast.error('Failed to save lead');
    }
  };

  const handleUnsaveLead = async (id: number) => {
    try {
      await leadService.unsaveLead(id);
      queryClient.setQueryData(['leads', searchQuery], (oldData: any) => {
        if (!oldData) return oldData;
        return {
          ...oldData,
          pages: oldData.pages.map((page: Lead[]) => 
            page.map(l => l.id === id ? { ...l, isSaved: false } : l)
          )
        };
      });
      if (selectedLead?.id === id) setSelectedLead({ ...selectedLead, isSaved: false });
      fetchSavedLeads();
      toast.info('Lead removed from saved');
    } catch (error) {
      console.error('Failed to unsave lead:', error);
      toast.error('Failed to remove lead');
    }
  };

  const handleEngageHighValue = () => {
    const highValueLeads = leads.filter((l: Lead) => l.conversionProbability >= 80);
    if (highValueLeads.length > 0) {
      toast.success(`Showing ${highValueLeads.length} high-value prospects`);
      // Scroll to table or apply filter
      const tableElement = document.getElementById('lead-table');
      tableElement?.scrollIntoView({ behavior: 'smooth' });
    } else {
      toast.info('Run a search to find high-value prospects');
    }
  };

  const highProbabilityLeads = leads.filter((l: Lead) => l.conversionProbability >= 80).length;

  return (
    <div className="min-h-screen flex font-sans text-slate-900 dark:text-white overflow-hidden relative bg-[#ede9fe] dark:bg-[#020617]">
      <Toaster position="top-right" richColors />
      <div className="hidden lg:block shrink-0">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      </div>
      
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto p-4 lg:p-6 custom-scrollbar relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-[1600px] mx-auto space-y-10 pb-20"
          >
            
            {/* Opportunity Banner */}
            <AnimatePresence>
              {(activeTab === 'search' || activeTab === 'dashboard') && leads.length > 0 && highProbabilityLeads > 0 && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95, y: -20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -20 }}
                  className="glass-panel border-indigo-200 dark:border-indigo-500/20 overflow-hidden relative group"
                >
                  <div className="p-6 flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
                    <div className="flex items-center gap-6 relative z-10">
                      <div className="w-14 h-14 bg-indigo-50 dark:bg-indigo-500/10 backdrop-blur-md rounded-2xl flex items-center justify-center shrink-0 border border-indigo-100 dark:border-indigo-500/20">
                        <Flame className="w-7 h-7 text-indigo-600 dark:text-indigo-500 animate-pulse" />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight">AI Prospect Opportunity</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                          We discovered <span className="font-bold text-indigo-600 dark:text-indigo-400">{highProbabilityLeads} high-intent leads</span> with conversion probabilities over 80%.
                        </p>
                      </div>
                    </div>
                    <button 
                      onClick={handleEngageHighValue}
                      className="px-6 py-3 glow-button text-white rounded-xl text-xs font-bold flex items-center gap-2 relative z-10"
                    >
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      Engage High-Value Prospects
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Metric Cards */}
            <div className="flex flex-wrap lg:flex-nowrap items-stretch gap-3">
              {[
                { label: 'Total Leads Found', value: stats?.totalLeads || 0, icon: Users, trend: '+12%', sub: 'this week', positive: true, tooltip: "Total unique leads discovered by the AI search engine." },
                { label: 'Avg Lead Score', value: stats?.avgLeadScore || 0, icon: Star, trend: '+5', sub: 'pts', positive: true, tooltip: "Lead Score represents AI evaluated purchase likelihood." },
                { label: 'Saved Prospects', value: stats?.savedLeads || 0, icon: Save, trend: '↑ +5', sub: 'today', positive: true, tooltip: "Number of leads you have saved for outreach campaigns." },
                { label: 'AI Messages', value: stats?.aiMessagesGenerated || 0, icon: MessageSquare, trend: '+18%', sub: 'growth', positive: true, tooltip: "Total AI-powered outreach messages generated for your leads." }
              ].map((card, i) => (
                <motion.div 
                  key={i} 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="flex-1 min-w-[150px] relative group overflow-hidden bg-white dark:bg-white/5 rounded-xl p-4 shadow-sm border border-slate-200 dark:border-white/10"
                >
                  {isLoading ? (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Skeleton className="w-20 h-2 bg-slate-100 dark:bg-white/10" />
                        <Skeleton className="w-6 h-6 rounded-lg bg-slate-100 dark:bg-white/10" />
                      </div>
                      <Skeleton className="w-16 h-6 bg-slate-100 dark:bg-white/10" />
                    </div>
                  ) : (
                    <div className="relative z-10 h-full flex flex-col justify-between">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">{card.label}</p>
                          <div className="flex items-center gap-1.5 mt-1">
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-indigo-50 dark:bg-indigo-500/10 border border-indigo-100 dark:border-indigo-500/20 text-indigo-600 dark:text-indigo-400">
                              {card.trend}
                            </span>
                            <span className="text-[9px] font-medium text-slate-400 dark:text-slate-500">{card.sub}</span>
                          </div>
                        </div>
                        <div className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-500/20 group-hover:scale-110 transition-transform duration-300">
                          <card.icon className="w-4 h-4" />
                        </div>
                      </div>
                      
                      <div className="flex items-end justify-between mt-auto">
                        <h4 className="text-3xl font-bold tracking-tight text-black dark:text-white leading-none">
                          <AnimatedCounter value={card.value} />
                        </h4>
                        <Tooltip content={card.tooltip}>
                          <div className="w-5 h-5 rounded-full bg-slate-50 dark:bg-white/5 flex items-center justify-center cursor-help hover:bg-slate-100 dark:hover:bg-white/10 transition-colors">
                            <Info className="w-3 h-3 text-slate-400 dark:text-slate-500" />
                          </div>
                        </Tooltip>
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>

            {/* Dashboard Content */}
            <div className="space-y-8">
              <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                <div>
                  <h2 className="text-4xl font-bold text-slate-900 dark:text-white tracking-tight">
                    {activeTab === 'search' || activeTab === 'dashboard' ? (
                      <>AI Lead <span className="text-indigo-600 dark:text-indigo-400">Discovery</span></>
                    ) : activeTab === 'saved' ? (
                      <>Saved <span className="text-indigo-600 dark:text-indigo-400">Prospects</span></>
                    ) : (
                      <>{activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} <span className="text-indigo-600 dark:text-indigo-400">Center</span></>
                    )}
                  </h2>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-2 font-medium">
                    {activeTab === 'search' || activeTab === 'dashboard' ? 'Find high-value B2B prospects using AI-powered discovery.' : 
                     activeTab === 'saved' ? 'Manage your saved prospects and outreach campaigns.' :
                     `Manage your ${activeTab} and AI configurations.`}
                  </p>
                </div>

                {(activeTab === 'search' || activeTab === 'saved' || activeTab === 'dashboard') && (
                  <div className="flex p-1 bg-slate-100 dark:bg-white/5 rounded-2xl border border-slate-200 dark:border-white/10 w-full md:w-auto">
                    <button 
                      onClick={() => setActiveTab('search')}
                      className={`flex-1 md:flex-none px-6 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all hover:scale-[1.02] active:scale-[0.98] ${activeTab === 'search' || activeTab === 'dashboard' ? 'bg-white dark:bg-indigo-600 text-indigo-600 dark:text-white shadow-md hover:shadow-lg' : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-white/10'}`}
                    >
                      Discovery
                    </button>
                    <button 
                      onClick={() => setActiveTab('saved')}
                      className={`flex-1 md:flex-none px-6 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all hover:scale-[1.02] active:scale-[0.98] ${activeTab === 'saved' ? 'bg-white dark:bg-indigo-600 text-indigo-600 dark:text-white shadow-md hover:shadow-lg' : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-white/10'}`}
                    >
                      Saved Leads ({savedLeads.length})
                    </button>
                  </div>
                )}
              </header>

              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-8"
                >
                  {(activeTab === 'search' || activeTab === 'dashboard' || activeTab === 'saved') ? (
                    <>
                      {(activeTab === 'search' || activeTab === 'dashboard') && (
                        <motion.div 
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="glass-panel p-8"
                        >
                          <SearchForm onSearch={handleSearch} isLoading={isFetching && !isFetchingNextPage} />
                        </motion.div>
                      )}

                      <motion.div 
                        id="lead-table"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="glass-panel overflow-hidden border-slate-100 dark:border-white/5"
                      >
                        <LeadTable 
                          leads={activeTab === 'saved' ? savedLeads : leads} 
                          onSelectLead={handleSelectLead}
                          selectedLeadId={selectedLead?.id || null}
                          onSaveLead={handleSaveLead}
                          onUnsaveLead={handleUnsaveLead}
                          isLoading={isLoading}
                        />

                        {(activeTab === 'search' || activeTab === 'dashboard') && hasNextPage && (
                          <div className="p-8 flex justify-center border-t border-slate-100 dark:border-white/5">
                            <button 
                              onClick={() => fetchNextPage()}
                              disabled={isFetchingNextPage}
                              className="px-8 py-3 bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-bold transition-all flex items-center gap-2 border border-slate-200 dark:border-white/10"
                            >
                              {isFetchingNextPage ? (
                                <>
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                  Loading more...
                                </>
                              ) : (
                                <>
                                  <Plus className="w-4 h-4" />
                                  Load More Leads
                                </>
                              )}
                            </button>
                          </div>
                        )}
                      </motion.div>
                    </>
                  ) : activeTab === 'analytics' ? (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                    >
                      <AnalyticsView leads={leads.length > 0 ? leads : savedLeads} />
                    </motion.div>
                  ) : activeTab === 'settings' ? (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                    >
                      <SettingsView />
                    </motion.div>
                  ) : activeTab === 'campaigns' ? (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                    >
                      <CampaignView />
                    </motion.div>
                  ) : activeTab === 'history' ? (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                    >
                      <HistoryView />
                    </motion.div>
                  ) : activeTab === 'api' ? (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                    >
                      <ApiKeyView />
                    </motion.div>
                  ) : (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="glass-panel p-20 flex flex-col items-center justify-center text-center space-y-6"
                    >
                      <div className="w-24 h-24 bg-indigo-50 dark:bg-indigo-500/10 rounded-[2.5rem] flex items-center justify-center border border-indigo-100 dark:border-indigo-500/20 shadow-inner">
                        <Sparkles className="w-10 h-10 text-indigo-500 animate-pulse" />
                      </div>
                      <div className="space-y-2">
                        <h3 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Module Optimization</h3>
                        <p className="text-slate-500 dark:text-slate-400 max-w-md mx-auto">
                          This workspace is being optimized with new AI features. Check back soon for the enterprise rollout.
                        </p>
                      </div>
                      <button 
                        onClick={() => setActiveTab('search')}
                        className="px-8 py-3 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/20 hover:bg-indigo-500 transition-all"
                      >
                        Return to Discovery
                      </button>
                    </motion.div>
                  )}
                </motion.div>
              </AnimatePresence>

              {/* AI Quick Insights & Analytics */}
              {(activeTab === 'search' || activeTab === 'dashboard' || activeTab === 'saved') && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <motion.div 
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    className="glass-panel p-8 space-y-8"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-xl flex items-center justify-center border border-indigo-100 dark:border-indigo-500/20 shadow-inner">
                        <Brain className="w-6 h-6" />
                      </div>
                      <h4 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight">AI Insights</h4>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {[
                        { icon: Briefcase, label: 'Top Industry', value: stats?.aiInsights.bestIndustry, badge: "🔥 Hot", badgeColor: "bg-orange-50 dark:bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-100 dark:border-orange-500/20" },
                        { icon: Star, label: 'MVP Prospect', value: stats?.aiInsights.topScoringLead, badge: "⭐ High", badgeColor: "bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-100 dark:border-amber-500/20" },
                        { icon: Clock, label: 'Best Time', value: stats?.aiInsights.recommendedTime, badge: "⚡ Fast", badgeColor: "bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-500/20" }
                      ].map((insight, i) => (
                        <div key={i} className="p-4 bg-slate-50 dark:bg-white/5 rounded-xl border border-slate-100 dark:border-white/5 group hover:border-slate-200 dark:hover:border-white/10 transition-all hover:bg-slate-100 dark:hover:bg-white/[0.07]">
                          <div className="flex items-center justify-between mb-3">
                            <insight.icon className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                            {(hasSearched || activeTab === 'saved') && (
                              <span className={`text-[8px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${insight.badgeColor}`}>
                                {insight.badge}
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1">{insight.label}</p>
                          <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{insight.value || '—'}</p>
                        </div>
                      ))}
                    </div>
                  </motion.div>

                  <motion.div 
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    className="glass-panel p-8"
                  >
                    <div className="flex items-center justify-between mb-8">
                      <h4 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-3">
                        <TrendingUp className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                        Conversion Analytics
                      </h4>
                    </div>
                    
                    <div className="space-y-6">
                      {[
                        { label: 'High Potential', value: stats?.probabilityDistribution.high || 0, gradient: 'from-emerald-400 to-teal-500' },
                        { label: 'Medium Fit', value: stats?.probabilityDistribution.medium || 0, gradient: 'from-indigo-400 to-blue-500' },
                        { label: 'Low Alignment', value: stats?.probabilityDistribution.low || 0, gradient: 'from-slate-300 to-slate-500' }
                      ].map((item, i) => {
                        const total = stats?.totalLeads || 0;
                        const percentage = total > 0 ? (item.value / total) * 100 : 0;
                        return (
                          <div key={i} className="space-y-2">
                            <div className="flex justify-between items-center text-[11px] font-bold">
                              <span className="text-slate-400 dark:text-slate-500 uppercase tracking-widest">{item.label}</span>
                              <span className="text-slate-900 dark:text-white">{item.value} ({Math.round(percentage)}%)</span>
                            </div>
                            <div className="h-2 w-full bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden">
                              <motion.div 
                                initial={{ width: 0 }}
                                whileInView={{ width: `${percentage}%` }}
                                transition={{ duration: 1, delay: i * 0.1 }}
                                className={`h-full bg-gradient-to-r ${item.gradient} rounded-full`}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </motion.div>
                </div>
              )}
            </div>
          </motion.div>
        </main>
      </div>

      {/* Floating AI Assistant Button */}
      <div className="fixed bottom-8 right-8 z-50">
        <motion.button 
          whileHover={{ scale: 1.1, boxShadow: "0 0 30px rgba(79, 70, 229, 0.4)" }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsFabOpen(true)}
          className="w-14 h-14 bg-gradient-to-r from-indigo-600 to-blue-600 text-white rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(79,70,229,0.3)] group relative overflow-hidden"
        >
          <MessageSquare className="w-7 h-7 relative z-10" />
          <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity"></div>
          {/* Pulsing glow effect */}
          <motion.div 
            animate={{ scale: [1, 1.2, 1], opacity: [0.2, 0.05, 0.2] }}
            transition={{ duration: 3, repeat: Infinity }}
            className="absolute inset-0 bg-indigo-400 rounded-full"
          />
        </motion.button>
      </div>

      {/* Floating AI Assistant Modal */}
      <AnimatePresence>
        {isFabOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-end justify-end p-4 md:p-8 pointer-events-none"
          >
            <div 
              className="absolute inset-0 bg-slate-900/40 dark:bg-slate-950/60 backdrop-blur-sm pointer-events-auto"
              onClick={() => setIsFabOpen(false)}
            />
            <motion.div 
              initial={{ y: 100, opacity: 0, scale: 0.95 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: 100, opacity: 0, scale: 0.95 }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="w-full max-w-[450px] h-[650px] bg-white dark:bg-slate-900 rounded-[32px] shadow-2xl border border-slate-200 dark:border-white/5 pointer-events-auto flex flex-col overflow-hidden relative"
            >
              <div className="p-6 border-b border-slate-100 dark:border-white/5 flex items-center justify-between shrink-0 bg-white/50 dark:bg-slate-900/50 backdrop-blur-md">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
                    <Brain className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">AI Assistant</h3>
                    <p className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest font-bold">LeadGen AI • v2.0</p>
                  </div>
                </div>
                <button onClick={() => setIsFabOpen(false)} className="text-slate-400 hover:text-slate-900 dark:text-slate-500 dark:hover:text-white transition-colors p-2 hover:bg-slate-100 dark:hover:bg-white/5 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 overflow-hidden">
                <AISalesAssistant selectedLead={selectedLead} />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Enrichment Drawer */}
      <AnimatePresence>
        {isDrawerOpen && selectedLead && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-900/40 dark:bg-slate-950/60 backdrop-blur-sm z-40 pointer-events-auto"
              onClick={() => setIsDrawerOpen(false)}
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: "spring", damping: 30, stiffness: 300 }}
              className="fixed right-0 top-0 h-full w-full max-w-2xl bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-white/5 z-50 flex flex-col shadow-2xl"
            >
              <div className="p-8 border-b border-slate-100 dark:border-white/5 flex items-center justify-between shrink-0 bg-white/50 dark:bg-slate-900/50 backdrop-blur-md">
                <div className="flex items-center gap-5">
                  <div className="w-14 h-14 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-xl shadow-indigo-600/20">
                    <Building2 className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">{selectedLead.companyName}</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-3">
                      <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4 text-indigo-600 dark:text-indigo-400" /> {selectedLead.location}</span>
                      <span className="w-1 h-1 bg-slate-200 dark:bg-slate-700 rounded-full" />
                      <span className="flex items-center gap-1.5"><Zap className="w-4 h-4 text-amber-500 dark:text-amber-400" /> {selectedLead.industry}</span>
                    </p>
                  </div>
                </div>
                <button onClick={() => setIsDrawerOpen(false)} className="text-slate-400 hover:text-slate-900 dark:text-slate-500 dark:hover:text-white transition-colors p-3 hover:bg-slate-100 dark:hover:bg-white/5 rounded-full">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
                <div className="flex p-1.5 bg-slate-100 dark:bg-white/5 rounded-2xl mb-10 border border-slate-200 dark:border-white/5">
                  <button 
                    onClick={() => setDrawerMode('enrich')}
                    className={`flex-1 py-3 text-[11px] font-bold uppercase tracking-[0.2em] rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98] ${drawerMode === 'enrich' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20 hover:shadow-indigo-600/30' : 'text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300 hover:bg-slate-200/50 dark:hover:bg-white/10'}`}
                  >
                    AI Intelligence
                  </button>
                  <button 
                    onClick={() => setDrawerMode('outreach')}
                    className={`flex-1 py-3 text-[11px] font-bold uppercase tracking-[0.2em] rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98] ${drawerMode === 'outreach' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20 hover:shadow-indigo-600/30' : 'text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300 hover:bg-slate-200/50 dark:hover:bg-white/10'}`}
                  >
                    Outreach Lab
                  </button>
                </div>

                {drawerMode === 'enrich' ? (
                  <EnrichmentPanel 
                    lead={selectedLead} 
                    onGenerateOutreach={() => setDrawerMode('outreach')}
                    onSaveLead={handleSaveLead}
                    onUnsaveLead={handleUnsaveLead}
                  />
                ) : (
                  <AIOutreachGenerator selectedLead={selectedLead} />
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
