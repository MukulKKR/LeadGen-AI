import React, { useState } from 'react';
import { Sparkles, Copy, RefreshCw, Check, Mail, Send, Target, Zap, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lead, leadService, OutreachResponse } from '../services/leadService';
import { toast } from 'sonner';

interface AIOutreachGeneratorProps {
  selectedLead: Lead | null;
}

const AIOutreachGenerator: React.FC<AIOutreachGeneratorProps> = ({ selectedLead }) => {
  const [outreach, setOutreach] = useState<OutreachResponse | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  const generateMessage = async () => {
    if (!selectedLead) return;
    setIsGenerating(true);
    try {
      const result = await leadService.generateOutreach(selectedLead);
      setOutreach(result);
    } catch (error) {
      console.error('Failed to generate outreach:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = () => {
    if (!outreach) return;
    const text = `Subject: ${outreach.subject}\n\n${outreach.body}`;
    navigator.clipboard.writeText(text);
    setIsCopied(true);
    toast.success('Message copied to clipboard');
    setTimeout(() => setIsCopied(false), 2000);
  };

  const sendMessage = () => {
    if (!outreach || !selectedLead) return;
    const mailtoUrl = `mailto:?subject=${encodeURIComponent(outreach.subject)}&body=${encodeURIComponent(outreach.body)}`;
    window.location.href = mailtoUrl;
    toast.success('Opening your email client...');
  };

  if (!selectedLead) {
    return (
      <div className="bg-slate-50 dark:bg-white/5 p-16 rounded-[2rem] border-2 border-dashed border-slate-100 dark:border-white/5 text-center space-y-6">
        <div className="w-20 h-20 bg-slate-100 dark:bg-white/5 text-slate-300 dark:text-slate-700 rounded-3xl flex items-center justify-center mx-auto border border-slate-100 dark:border-white/5">
          <Mail className="w-10 h-10" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">Select a prospect</h3>
          <p className="text-sm text-slate-500 mt-2 font-medium">
            Choose a lead to start crafting a personalized outreach campaign.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <AnimatePresence mode="wait">
        {!outreach && !isGenerating ? (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-slate-50 dark:bg-white/5 p-16 rounded-[2rem] text-center space-y-8 border border-slate-100 dark:border-white/5 shadow-inner"
          >
            <div className="w-20 h-20 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-3xl flex items-center justify-center mx-auto border border-indigo-100 dark:border-indigo-500/20">
              <Sparkles className="w-10 h-10" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">Ready to engage?</h3>
              <p className="text-sm text-slate-500 mt-2 max-w-[320px] mx-auto leading-relaxed font-medium">
                AI will craft a high-converting, personalized message tailored for {selectedLead.companyName}.
              </p>
            </div>
            <motion.button 
              whileHover={{ scale: 1.05, translateY: -2, boxShadow: "0 20px 40px -10px rgba(79, 70, 229, 0.4)" }}
              whileTap={{ scale: 0.95 }}
              onClick={generateMessage}
              className="px-10 py-4 glow-button text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-3 mx-auto"
            >
              <Zap className="w-5 h-5 text-amber-300" />
              Generate Message
            </motion.button>
          </motion.div>
        ) : isGenerating ? (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="bg-slate-50 dark:bg-white/5 p-16 rounded-[2rem] text-center space-y-10 border border-slate-100 dark:border-white/5 shadow-inner"
          >
            <div className="relative w-24 h-24 mx-auto">
              <div className="absolute inset-0 rounded-3xl border-2 border-slate-100 dark:border-white/5 shadow-inner"></div>
              <div className="absolute inset-0 rounded-3xl border-2 border-t-indigo-500 animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Sparkles className="w-10 h-10 text-indigo-500 animate-pulse" />
              </div>
            </div>
            <div className="space-y-3">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">AI is crafting your pitch...</h3>
              <p className="text-sm text-slate-500 leading-relaxed font-medium">Analyzing industry trends and pain points for {selectedLead.companyName}.</p>
            </div>
          </motion.div>
        ) : outreach && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="bg-white dark:bg-white/5 rounded-[2rem] border border-slate-200 dark:border-white/5 overflow-hidden shadow-2xl">
              <div className="p-5 bg-slate-50 dark:bg-white/5 border-b border-slate-100 dark:border-white/5 flex items-center justify-between backdrop-blur-md">
                <div className="flex items-center gap-4">
                  <div className="w-11 h-11 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-xl flex items-center justify-center border border-indigo-100 dark:border-indigo-500/20 shadow-inner">
                    <Mail className="w-5 h-5" />
                  </div>
                  <span className="text-[11px] font-bold text-slate-900 dark:text-white uppercase tracking-[0.2em]">Personalized Outreach</span>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={generateMessage}
                    className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-slate-900 dark:text-slate-500 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5 rounded-xl transition-all"
                    title="Regenerate"
                  >
                    <RefreshCw className="w-4.5 h-4.5" />
                  </button>
                  <button 
                    onClick={copyToClipboard}
                    className={`w-10 h-10 flex items-center justify-center rounded-xl transition-all ${isCopied ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-400/10 border border-emerald-100 dark:border-emerald-400/20' : 'text-slate-400 hover:text-slate-900 dark:text-slate-500 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5'}`}
                  >
                    {isCopied ? <Check className="w-4.5 h-4.5" /> : <Copy className="w-4.5 h-4.5" />}
                  </button>
                </div>
              </div>
              <div className="p-8 space-y-8">
                <div className="space-y-3">
                  <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">Subject Line</p>
                  <div className="text-sm font-bold text-slate-900 dark:text-white bg-slate-50 dark:bg-white/5 p-5 rounded-2xl border border-slate-100 dark:border-white/5 shadow-inner">
                    {outreach.subject}
                  </div>
                </div>
                <div className="space-y-3">
                  <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">Message Body</p>
                  <div className="bg-slate-50 dark:bg-white/5 p-8 rounded-2xl border border-slate-100 dark:border-white/5 text-[13px] text-slate-700 dark:text-slate-200 font-medium leading-relaxed whitespace-pre-wrap shadow-inner min-h-[200px]">
                    {outreach.body}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-5 p-5 bg-emerald-50 dark:bg-emerald-500/5 border border-emerald-100 dark:border-emerald-500/10 rounded-2xl shadow-sm">
              <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-center shrink-0 border border-emerald-100 dark:border-emerald-400/20">
                <Target className="w-6 h-6" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-[0.2em]">Engagement Score</p>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 font-medium">AI predicts a <span className="text-emerald-600 dark:text-emerald-400 font-bold">94% probability</span> of positive response.</p>
              </div>
            </div>
            
            <motion.button 
              whileHover={{ scale: 1.02, translateY: -2, boxShadow: "0 20px 40px -10px rgba(79, 70, 229, 0.4)" }}
              whileTap={{ scale: 0.98 }}
              className="w-full py-5 glow-button text-white rounded-2xl text-[13px] font-bold flex items-center justify-center gap-3 shadow-xl transition-all"
              onClick={sendMessage}
            >
              Send via Email
              <Send className="w-5 h-5" />
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AIOutreachGenerator;
