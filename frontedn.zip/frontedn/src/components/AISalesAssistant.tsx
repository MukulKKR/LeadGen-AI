import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  Send, 
  Brain, 
  Target, 
  MessageSquare,
  Zap,
  TrendingUp,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lead } from '../services/leadService';
import { useChat } from '@ai-sdk/react';
import { DefaultChatTransport } from 'ai';

interface AISalesAssistantProps {
  selectedLead: Lead | null;
}

const AISalesAssistant: React.FC<AISalesAssistantProps> = ({ selectedLead }) => {
  const [chatInput, setChatInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const { messages, sendMessage, status } = useChat({
    transport: new DefaultChatTransport({
      api: `${import.meta.env.VITE_API_BASE_URL}/ai/chat`
    }),
    initialMessages: [
      { 
        id: 'system', 
        role: 'system', 
        content: 'You are an expert AI Sales Assistant. Help the user analyze B2B leads and develop winning outreach strategies.' 
      } as any
    ]
  } as any);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = (text: string) => {
    if (!text.trim() || status !== 'ready') return;

    sendMessage({
      text,
      body: {
        context: selectedLead ? {
          companyName: selectedLead.companyName,
          industry: selectedLead.industry,
          description: selectedLead.description
        } : undefined
      }
    } as any);
    setChatInput('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(chatInput);
  };

  const getMessageText = (message: any): string => {
    let fullText = message.content || '';
    const parts = message.parts || [];
    if (parts.length > 0) {
      fullText = parts
        .filter((part: any) => part.type === 'text')
        .map((part: any) => part.text)
        .join('');
    }
    return fullText;
  };

  const suggestedPrompts = selectedLead 
    ? ["Analyze this prospect", "Predict conversion probability", "Generate personalized outreach"]
    : ["Analyze latest leads", "Show best prospects", "Recommend targeting strategy"];

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
        {selectedLead && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            {/* Context Header */}
            <div className="flex items-center gap-3 p-4 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5">
              <div className="w-9 h-9 bg-indigo-50 dark:bg-indigo-500/10 rounded-xl flex items-center justify-center shrink-0 border border-indigo-100 dark:border-indigo-500/20">
                <Target className="w-4.5 h-4.5 text-indigo-600 dark:text-indigo-400" />
              </div>
              <div>
                <p className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Active Context</p>
                <p className="text-xs font-bold text-slate-900 dark:text-white">{selectedLead.companyName}</p>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5 flex flex-col items-center">
                <span className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">{selectedLead.conversionProbability}%</span>
                <span className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] mt-1.5">Probability</span>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5 flex flex-col items-center">
                <span className="text-2xl font-bold text-indigo-600 dark:text-indigo-400 tracking-tight">{selectedLead.leadScore}</span>
                <span className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] mt-1.5">Lead Score</span>
              </div>
            </div>

            {/* AI Insights Summary */}
            <div className="p-5 bg-indigo-50 dark:bg-indigo-500/5 rounded-2xl border border-indigo-100 dark:border-indigo-500/10 shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">Strategy Angle</span>
              </div>
              <p className="text-xs font-medium text-slate-600 dark:text-slate-300 leading-relaxed">
                {selectedLead.outreachRecommendation?.strategy || `Target ${selectedLead.companyName} with focus on industry-specific value props.`}
              </p>
            </div>
          </motion.div>
        )}

        {/* Chat Messages */}
        <div className="space-y-5">
          <AnimatePresence mode="popLayout">
            {messages.filter(m => m.role !== 'system').map((message) => (
              <motion.div 
                key={message.id} 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[85%] px-5 py-3.5 rounded-2xl text-[13px] font-medium leading-relaxed shadow-sm ${
                  message.role === 'user' 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' 
                    : 'bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-white/5'
                }`}>
                  {getMessageText(message)}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          {status === 'submitted' && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-start"
            >
              <div className="bg-slate-100 dark:bg-white/5 px-5 py-3.5 rounded-2xl border border-slate-200 dark:border-white/5">
                <div className="flex gap-1.5">
                  <span className="w-1.5 h-1.5 bg-indigo-400/30 rounded-full animate-bounce" />
                  <span className="w-1.5 h-1.5 bg-indigo-400/50 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 bg-indigo-400/70 rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            </motion.div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Suggested Prompts */}
        {messages.filter(m => m.role !== 'system').length === 0 && (
          <div className="space-y-4">
            <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">Suggested Prompts</p>
            <div className="flex flex-col gap-2.5">
              {suggestedPrompts.map((prompt, i) => (
                <button
                  key={i}
                  onClick={() => handleSendMessage(prompt)}
                  className="px-5 py-4 bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5 rounded-2xl text-[13px] font-medium text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 hover:border-slate-200 dark:hover:border-white/10 transition-all text-left active:scale-[0.98] shadow-sm"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-6 border-t border-slate-100 dark:border-white/5 shrink-0 bg-white/50 dark:bg-slate-900/50 backdrop-blur-md">
        <form onSubmit={handleSubmit} className="relative">
          <input 
            type="text" 
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder="Ask anything about sales strategy..."
            className="w-full bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/5 rounded-2xl py-4 pl-5 pr-14 text-[13px] font-medium focus:outline-none focus:border-indigo-500/50 focus:bg-white dark:focus:bg-white/10 transition-all text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-600 shadow-inner"
          />
          <motion.button 
            whileHover={{ scale: 1.1, rotate: -10 }}
            whileTap={{ scale: 0.9 }}
            type="submit"
            disabled={!chatInput.trim() || status !== 'ready'}
            className="absolute right-2.5 top-2.5 w-10 h-10 bg-indigo-600 text-white rounded-xl flex items-center justify-center hover:bg-indigo-500 transition-all disabled:opacity-50 shadow-lg shadow-indigo-600/30"
          >
            <Send className="w-4.5 h-4.5" />
          </motion.button>
        </form>
      </div>
    </div>

  );
};

export default AISalesAssistant;
