import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, 
  Users, 
  Target, 
  Zap, 
  BarChart3, 
  PieChart, 
  ArrowUpRight, 
  ArrowDownRight,
  Calendar,
  Filter,
  Download,
  MoreVertical,
  Briefcase,
  MapPin,
  Star,
  Activity,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { Lead } from '../services/leadService';
import { toast } from 'sonner';

interface AnalyticsViewProps {
  leads: Lead[];
}

const AnalyticsView: React.FC<AnalyticsViewProps> = ({ leads }) => {
  // Mock analytics data based on current leads
  const stats = useMemo(() => {
    const totalLeads = leads.length;
    if (totalLeads === 0) return null;

    const avgLeadScore = Math.round(leads.reduce((sum, l) => sum + l.leadScore, 0) / totalLeads);
    const avgProbability = Math.round(leads.reduce((sum, l) => sum + l.conversionProbability, 0) / totalLeads);
    
    // Industry distribution
    const industryCounts = leads.reduce((acc, lead) => {
      acc[lead.industry] = (acc[lead.industry] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const topIndustries = Object.entries(industryCounts)
      .map(([name, count]) => ({ name, count, percentage: Math.round((count / totalLeads) * 100) }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    // Score distribution
    const scoreRanges = {
      '90-100': leads.filter(l => l.leadScore >= 90).length,
      '70-89': leads.filter(l => l.leadScore >= 70 && l.leadScore < 90).length,
      '50-69': leads.filter(l => l.leadScore >= 50 && l.leadScore < 70).length,
      '<50': leads.filter(l => l.leadScore < 50).length,
    };

    // Location distribution
    const locationCounts = leads.reduce((acc, lead) => {
      acc[lead.location] = (acc[lead.location] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const topLocations = Object.entries(locationCounts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 4);

    const maxPercentage = Math.max(...topIndustries.map(i => i.percentage), 1);
    const scaleFactor = 200 / maxPercentage; // Use 200px as max height

    return {
      totalLeads,
      avgLeadScore,
      avgProbability,
      topIndustries,
      scoreRanges,
      topLocations,
      scaleFactor
    };
  }, [leads]);

  if (!stats) {
    return (
      <div className="glass-panel p-20 flex flex-col items-center justify-center text-center space-y-6">
        <div className="w-24 h-24 bg-indigo-50 dark:bg-indigo-500/10 rounded-[2.5rem] flex items-center justify-center border border-indigo-100 dark:border-indigo-500/20 shadow-inner">
          <BarChart3 className="w-10 h-10 text-indigo-500" />
        </div>
        <div className="space-y-2">
          <h3 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">No Analytics Data</h3>
          <p className="text-slate-500 dark:text-slate-400 max-w-md mx-auto">
            Run a search or save some leads to see your conversion analytics and performance metrics.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-10">
      {/* Analytics Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-600/20">
            <Activity className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Performance Intelligence</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">Deep dive into your lead pipeline and conversion metrics</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <button 
            onClick={() => toast.info('Date range filter coming soon!')}
            className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/10 transition-all hover:scale-[1.02] active:scale-[0.98] hover:shadow-md"
          >
            <Calendar className="w-4 h-4" />
            Last 30 Days
          </button>
          <button 
            onClick={() => toast.success('Analytics report exported successfully!')}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/20 hover:bg-indigo-500 transition-all hover:scale-[1.02] active:scale-[0.98] hover:shadow-indigo-600/40"
          >
            <Download className="w-4 h-4" />
            Export Report
          </button>
        </div>
      </div>

      {/* High Level Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Conversion Rate', value: '24.8%', icon: Target, trend: '+3.2%', positive: true },
          { label: 'Pipeline Value', value: '$142k', icon: Zap, trend: '+12%', positive: true },
          { label: 'Avg. Lead Score', value: stats.avgLeadScore, icon: Star, trend: '+5', positive: true },
          { label: 'Engagement Rate', value: '68%', icon: Users, trend: '-2.4%', positive: false },
        ].map((card, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="glass-panel p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <div className="p-2 bg-indigo-50 dark:bg-indigo-500/10 rounded-lg border border-indigo-100 dark:border-indigo-500/20">
                <card.icon className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              </div>
              <div className={`flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${card.positive ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400'}`}>
                {card.positive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                {card.trend}
              </div>
            </div>
            <div>
              <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">{card.label}</p>
              <h4 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">{card.value}</h4>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Industry Distribution Chart (Custom SVG Bar Chart) */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-2 glass-panel p-8"
        >
          <div className="flex items-center justify-between mb-8">
            <h4 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-3">
              <Briefcase className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              Leads by Industry
            </h4>
            <div className="flex items-center gap-2">
              <button className="p-1.5 hover:bg-slate-50 dark:hover:bg-white/5 rounded-lg transition-colors">
                <Filter className="w-4 h-4 text-slate-400" />
              </button>
              <button className="p-1.5 hover:bg-slate-50 dark:hover:bg-white/5 rounded-lg transition-colors">
                <MoreVertical className="w-4 h-4 text-slate-400" />
              </button>
            </div>
          </div>

          <div className="h-64 flex items-end justify-between gap-4 mt-10">
            {stats.topIndustries.map((item, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-4 group">
                <div className="relative w-full flex flex-col items-center">
                  {/* Tooltip on hover */}
                  <div className="absolute -top-10 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-[10px] font-bold px-2 py-1 rounded shadow-lg z-20 pointer-events-none whitespace-nowrap">
                    {item.count} Leads
                  </div>
                  <motion.div 
                    initial={{ height: 0 }}
                    animate={{ height: `${item.percentage * stats.scaleFactor}px` }}
                    transition={{ duration: 1, delay: i * 0.1, ease: "easeOut" }}
                    className="w-full max-w-[40px] bg-gradient-to-t from-indigo-600 to-indigo-400 rounded-t-lg shadow-lg shadow-indigo-500/20 relative"
                  >
                    <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity rounded-t-lg" />
                  </motion.div>
                </div>
                <div className="text-center">
                  <p className="text-[10px] font-bold text-slate-900 dark:text-white truncate max-w-[60px]">{item.name}</p>
                  <p className="text-[9px] font-medium text-slate-400 dark:text-slate-500 mt-0.5">{item.percentage}%</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Lead Score Distribution */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass-panel p-8"
        >
          <div className="flex items-center justify-between mb-8">
            <h4 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-3">
              <PieChart className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              Score Range
            </h4>
          </div>

          <div className="space-y-6">
            {Object.entries(stats.scoreRanges).map(([range, count], i) => {
              const percentage = Math.round((count / stats.totalLeads) * 100);
              const colors = [
                'bg-emerald-500',
                'bg-indigo-500',
                'bg-amber-500',
                'bg-slate-400'
              ];
              return (
                <div key={i} className="space-y-2">
                  <div className="flex justify-between items-center text-[11px] font-bold">
                    <span className="text-slate-400 dark:text-slate-500 uppercase tracking-widest">{range} Score</span>
                    <span className="text-slate-900 dark:text-white">{count} ({percentage}%)</span>
                  </div>
                  <div className="h-2 w-full bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${percentage}%` }}
                      transition={{ duration: 1, delay: i * 0.1 }}
                      className={`h-full ${colors[i % colors.length]} rounded-full`}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-10 p-4 bg-indigo-50 dark:bg-indigo-500/5 rounded-xl border border-indigo-100 dark:border-indigo-500/10">
            <div className="flex items-start gap-3">
              <div className="p-1.5 bg-indigo-600 rounded-lg shrink-0 mt-0.5">
                <TrendingUp className="w-3 h-3 text-white" />
              </div>
              <div>
                <p className="text-[11px] font-bold text-slate-900 dark:text-white">AI Prediction</p>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                  Based on current trends, your pipeline health is <span className="text-emerald-600 font-bold">Excellent</span>. We recommend focusing on the 70-89 score segment for rapid growth.
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Top Locations & Performance Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-panel p-8"
        >
          <h4 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-3 mb-8">
            <MapPin className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            Geographic Distribution
          </h4>
          
          <div className="space-y-4">
            {stats.topLocations.map((loc, i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-white/5 rounded-xl border border-slate-100 dark:border-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-white dark:bg-white/10 flex items-center justify-center text-xs font-bold text-indigo-600 dark:text-indigo-400 border border-slate-100 dark:border-white/5">
                    {i + 1}
                  </div>
                  <span className="text-sm font-bold text-slate-900 dark:text-white">{loc.name}</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-[10px] font-bold text-slate-900 dark:text-white">{loc.count} Leads</p>
                    <p className="text-[9px] text-slate-500 dark:text-slate-400 uppercase tracking-widest font-bold">Active Market</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-300" />
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-panel p-8"
        >
          <div className="flex items-center justify-between mb-8">
            <h4 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-3">
              <Users className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              Lead Quality Trend
            </h4>
            <div className="px-3 py-1 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold rounded-full border border-emerald-100 dark:border-emerald-500/20">
              Live Data
            </div>
          </div>

          <div className="space-y-6">
            <div className="h-40 w-full relative">
              {/* Simple Line Chart SVG */}
              <svg className="w-full h-full overflow-visible" viewBox="0 0 400 100">
                <defs>
                  <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#4f46e5" stopOpacity="0.2" />
                    <stop offset="50%" stopColor="#4f46e5" stopOpacity="1" />
                    <stop offset="100%" stopColor="#4f46e5" stopOpacity="0.6" />
                  </linearGradient>
                  <linearGradient id="areaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#4f46e5" stopOpacity="0.2" />
                    <stop offset="100%" stopColor="#4f46e5" stopOpacity="0" />
                  </linearGradient>
                </defs>
                
                {/* Area under the line */}
                <motion.path 
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={{ pathLength: 1, opacity: 1 }}
                  transition={{ duration: 1.5, ease: "easeInOut" }}
                  d="M0,80 Q50,60 100,70 T200,40 T300,50 T400,20 V100 H0 Z" 
                  fill="url(#areaGradient)"
                />
                
                {/* The line itself */}
                <motion.path 
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 1.5, ease: "easeInOut" }}
                  d="M0,80 Q50,60 100,70 T200,40 T300,50 T400,20" 
                  fill="none" 
                  stroke="url(#lineGradient)" 
                  strokeWidth="3" 
                  strokeLinecap="round"
                />
                
                {/* Animated data points */}
                <motion.circle 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 1.5 }}
                  cx="400" cy="20" r="4" fill="#4f46e5" stroke="white" strokeWidth="2" 
                />
              </svg>
              
              <div className="absolute top-0 right-0 flex flex-col items-end">
                <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400">+18.5% Growth</span>
                <span className="text-[9px] text-slate-400 dark:text-slate-500">Quality Index</span>
              </div>
            </div>
            
            <div className="grid grid-cols-4 gap-2 text-center">
              {['Week 1', 'Week 2', 'Week 3', 'Week 4'].map((week, i) => (
                <span key={i} className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">{week}</span>
              ))}
            </div>
          </div>

          <div className="mt-8 flex items-center justify-between p-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl shadow-xl shadow-indigo-600/10">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-indigo-400" />
              </div>
              <span className="text-xs font-bold">Optimization Complete</span>
            </div>
            <button className="text-[10px] font-bold uppercase tracking-widest bg-white/10 dark:bg-slate-900/10 px-3 py-1.5 rounded-lg hover:bg-white/20 transition-colors">
              View Insights
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AnalyticsView;
