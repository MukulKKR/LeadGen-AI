import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Zap, 
  Key, 
  Copy, 
  RefreshCcw, 
  ShieldCheck, 
  Eye, 
  EyeOff, 
  Plus, 
  CheckCircle2,
  ExternalLink,
  Lock,
  Trash2,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';

interface ApiKey {
  id: string;
  name: string;
  provider: string;
  key: string;
  lastUsed: string;
  status: 'active' | 'revoked';
}

const MOCK_KEYS: ApiKey[] = [
  { id: '1', name: 'Production LeadGen AI', provider: 'System', key: 'lg_sk_live_8f3k2j9s1m5n4b6v', lastActive: '2 mins ago', status: 'active' } as any,
  { id: '2', name: 'OpenAI Integration', provider: 'OpenAI', key: 'sk-proj-4k2j9s1m5n4b6v8f3k2j9s1m5n', lastActive: '1 hour ago', status: 'active' } as any,
  { id: '3', name: 'HubSpot Sync', provider: 'HubSpot', key: 'pat-na1-8f3k2j9s1m5n4b6v8f3k2j9s1m5n', lastActive: 'Yesterday', status: 'active' } as any,
  { id: '4', name: 'Legacy Data Key', provider: 'System', key: 'lg_sk_test_1m5n4b6v8f3k2j9s', lastActive: '2 months ago', status: 'revoked' } as any,
];

const ApiKeyView: React.FC = () => {
  const [keys, setKeys] = useState<ApiKey[]>(MOCK_KEYS);
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});

  const toggleVisibility = (id: string) => {
    setShowKeys(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const copyToClipboard = (key: string) => {
    navigator.clipboard.writeText(key);
    toast.success('API Key copied to clipboard');
  };

  const regenerateKey = (id: string) => {
    toast.promise(
      new Promise((resolve) => setTimeout(resolve, 1500)),
      {
        loading: 'Regenerating secure key...',
        success: 'New API key generated successfully',
        error: 'Failed to regenerate key',
      }
    );
  };

  const revokeKey = (id: string) => {
    setKeys(prev => prev.map(k => k.id === id ? { ...k, status: 'revoked' } : k));
    toast.warning('API key has been revoked');
  };

  return (
    <div className="space-y-8 pb-10">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-600/20">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">API Infrastructure</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">Manage secure authentication keys and external service integrations</p>
          </div>
        </div>
        
        <button 
          onClick={() => toast.info('Key creation wizard coming soon!')}
          className="flex items-center gap-2 px-6 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/20 hover:bg-indigo-500 transition-all hover:scale-[1.02] active:scale-[0.98]"
        >
          <Plus className="w-4 h-4" />
          Generate New Key
        </button>
      </div>

      {/* Security Banner */}
      <div className="p-4 bg-amber-50 dark:bg-amber-500/5 border border-amber-100 dark:border-amber-500/20 rounded-2xl flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="text-xs font-bold text-amber-900 dark:text-amber-400">Security Best Practices</p>
          <p className="text-[11px] text-amber-800/70 dark:text-amber-400/70 leading-relaxed">
            Never share your secret API keys in public spaces or commit them to version control. If a key is compromised, revoke it immediately and generate a new one.
          </p>
        </div>
      </div>

      {/* Keys List */}
      <div className="grid grid-cols-1 gap-4">
        {keys.map((apiKey, i) => (
          <motion.div 
            key={apiKey.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className={`glass-panel p-6 border transition-all ${apiKey.status === 'revoked' ? 'opacity-60 grayscale' : 'hover:border-indigo-200 dark:hover:border-indigo-500/30'}`}
          >
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              <div className="flex items-start gap-4 flex-1">
                <div className={`p-3 rounded-xl shrink-0 ${
                  apiKey.provider === 'System' ? 'bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600' :
                  apiKey.provider === 'OpenAI' ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600' :
                  'bg-orange-50 dark:bg-orange-500/10 text-orange-600'
                }`}>
                  <Key className="w-5 h-5" />
                </div>
                <div className="space-y-3 flex-1">
                  <div className="flex items-center gap-3">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">{apiKey.name}</h4>
                    <span className={`px-2 py-0.5 rounded-full text-[8px] font-bold uppercase tracking-widest ${
                      apiKey.status === 'active' ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600' : 'bg-slate-100 dark:bg-white/10 text-slate-500'
                    }`}>
                      {apiKey.status}
                    </span>
                  </div>
                  
                  <div className="flex flex-col md:flex-row md:items-center gap-2">
                    <div className="flex-1 relative">
                      <input 
                        type={showKeys[apiKey.id] ? 'text' : 'password'} 
                        readOnly
                        value={apiKey.key}
                        className="w-full bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-lg px-4 py-2.5 text-xs font-mono text-slate-600 dark:text-slate-400 focus:outline-none"
                      />
                      <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                        <button 
                          onClick={() => toggleVisibility(apiKey.id)}
                          className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                        >
                          {showKeys[apiKey.id] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                        <button 
                          onClick={() => copyToClipboard(apiKey.key)}
                          className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest">
                    <span className="flex items-center gap-1.5"><ShieldCheck className="w-3 h-3 text-emerald-500" /> Secure Storage</span>
                    <span className="w-1 h-1 bg-slate-200 dark:bg-slate-700 rounded-full" />
                    <span>Last used: {apiKey.lastUsed || 'Just now'}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end lg:self-center">
                {apiKey.status === 'active' ? (
                  <>
                    <button 
                      onClick={() => regenerateKey(apiKey.id)}
                      className="flex items-center gap-2 px-4 py-2 bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 text-slate-600 dark:text-slate-300 rounded-xl text-[10px] font-bold transition-all border border-slate-200 dark:border-white/10"
                    >
                      <RefreshCcw className="w-3 h-3" />
                      Regenerate
                    </button>
                    <button 
                      onClick={() => revokeKey(apiKey.id)}
                      className="p-2.5 text-slate-300 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-xl transition-all border border-transparent hover:border-rose-100"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </>
                ) : (
                  <button 
                    onClick={() => setKeys(prev => prev.map(k => k.id === apiKey.id ? { ...k, status: 'active' } : k))}
                    className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-[10px] font-bold shadow-lg shadow-indigo-600/20 hover:bg-indigo-500 transition-all"
                  >
                    Re-activate Key
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Integration Documentation */}
      <div className="p-8 bg-slate-900 dark:bg-indigo-950 rounded-[2.5rem] text-white relative overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-3">
            <h4 className="text-xl font-bold flex items-center gap-3">
              <Lock className="w-6 h-6 text-indigo-400" />
              Developer API Documentation
            </h4>
            <p className="text-indigo-200/60 text-sm max-w-xl">
              Integrate LeadGen AI directly into your applications with our robust REST API. Access lead discovery, scoring, and outreach generation programmatically.
            </p>
          </div>
          <button className="flex items-center gap-2 px-8 py-3 bg-white text-indigo-950 rounded-2xl text-xs font-bold shadow-2xl transition-all hover:scale-[1.05]">
            Read API Docs
            <ExternalLink className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ApiKeyView;
