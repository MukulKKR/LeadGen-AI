import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Target, 
  Plus, 
  Search, 
  MoreVertical, 
  Play, 
  Pause, 
  Users, 
  Mail, 
  MousePointer2, 
  BarChart3, 
  ChevronRight,
  Sparkles,
  Clock,
  CheckCircle2,
  AlertCircle,
  Zap
} from 'lucide-react';
import { toast } from 'sonner';

interface Campaign {
  id: string;
  name: string;
  status: 'active' | 'paused' | 'completed' | 'draft';
  leadsCount: number;
  openRate: number;
  clickRate: number;
  lastActive: string;
  type: 'Email' | 'LinkedIn' | 'Multi-Channel';
}

const MOCK_CAMPAIGNS: Campaign[] = [
  { id: '1', name: 'Q1 Tech Startup Outreach', status: 'active', leadsCount: 450, openRate: 64, clickRate: 18, lastActive: '2 mins ago', type: 'Email' },
  { id: '2', name: 'Enterprise SaaS Re-engagement', status: 'active', leadsCount: 1200, openRate: 42, clickRate: 12, lastActive: '1 hour ago', type: 'Multi-Channel' },
  { id: '3', name: 'LinkedIn Personal Branding', status: 'paused', leadsCount: 150, openRate: 0, clickRate: 0, lastActive: 'Yesterday', type: 'LinkedIn' },
  { id: '4', name: 'Inbound Follow-up Automation', status: 'completed', leadsCount: 890, openRate: 78, clickRate: 34, lastActive: '3 days ago', type: 'Email' },
  { id: '5', name: 'Dormant Leads Recovery', status: 'draft', leadsCount: 0, openRate: 0, clickRate: 0, lastActive: 'Never', type: 'Multi-Channel' },
];

const CampaignView: React.FC = () => {
  const [campaigns, setCampaigns] = useState<Campaign[]>(MOCK_CAMPAIGNS);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCampaigns = campaigns.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleCampaignStatus = (id: string) => {
    setCampaigns(prev => prev.map(c => {
      if (c.id === id) {
        const newStatus = c.status === 'active' ? 'paused' : 'active';
        toast.success(`Campaign ${newStatus === 'active' ? 'resumed' : 'paused'} successfully`);
        return { ...c, status: newStatus as any };
      }
      return c;
    }));
  };

  const deleteCampaign = (id: string) => {
    setCampaigns(prev => prev.filter(c => c.id !== id));
    toast.success('Campaign deleted successfully');
  };

  return (
    <div className="space-y-8 pb-10">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-600/20">
            <Target className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Campaign Management</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">Deploy and monitor AI-driven outreach sequences</p>
          </div>
        </div>
        
        <button 
          onClick={() => toast.info('Campaign creator coming soon!')}
          className="flex items-center gap-2 px-6 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/20 hover:bg-indigo-500 transition-all hover:scale-[1.02] active:scale-[0.98]"
        >
          <Plus className="w-4 h-4" />
          Create New Campaign
        </button>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { label: 'Active Campaigns', value: campaigns.filter(c => c.status === 'active').length, icon: Play, color: 'text-emerald-500', bg: 'bg-emerald-50 dark:bg-emerald-500/10' },
          { label: 'Total Leads Reached', value: '2.5k', icon: Users, color: 'text-indigo-500', bg: 'bg-indigo-50 dark:bg-indigo-500/10' },
          { label: 'Avg. Engagement', value: '54%', icon: BarChart3, color: 'text-amber-500', bg: 'bg-amber-50 dark:bg-amber-500/10' },
        ].map((stat, i) => (
          <div key={i} className="glass-panel p-6 flex items-center justify-between">
            <div>
              <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">{stat.label}</p>
              <h4 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">{stat.value}</h4>
            </div>
            <div className={`p-3 rounded-xl ${stat.bg} ${stat.color}`}>
              <stat.icon className="w-5 h-5" />
            </div>
          </div>
        ))}
      </div>

      {/* Campaign List */}
      <div className="glass-panel overflow-hidden">
        <div className="p-6 border-b border-slate-100 dark:border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Filter campaigns..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl pl-10 pr-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all text-slate-900 dark:text-white"
            />
          </div>
          <div className="flex items-center gap-2">
            <select className="bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl px-4 py-2 text-xs font-bold outline-none cursor-pointer text-slate-600 dark:text-slate-300">
              <option>All Status</option>
              <option>Active</option>
              <option>Paused</option>
              <option>Completed</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50 dark:bg-white/[0.02] border-b border-slate-100 dark:border-white/5">
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Campaign Name</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Status</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Leads</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Performance</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Last Activity</th>
                <th className="px-6 py-4 text-right"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-white/5">
              {filteredCampaigns.map((campaign) => (
                <motion.tr 
                  key={campaign.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="hover:bg-slate-50 dark:hover:bg-white/[0.02] transition-colors group"
                >
                  <td className="px-6 py-5">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${
                        campaign.type === 'Email' ? 'bg-blue-50 dark:bg-blue-500/10 border-blue-100 dark:border-blue-500/20 text-blue-600' :
                        campaign.type === 'LinkedIn' ? 'bg-indigo-50 dark:bg-indigo-500/10 border-indigo-100 dark:border-indigo-500/20 text-indigo-600' :
                        'bg-purple-50 dark:bg-purple-500/10 border-purple-100 dark:border-purple-500/20 text-purple-600'
                      }`}>
                        {campaign.type === 'Email' ? <Mail className="w-5 h-5" /> : 
                         campaign.type === 'LinkedIn' ? <Users className="w-5 h-5" /> : 
                         <Zap className="w-5 h-5" />}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">{campaign.name}</p>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium uppercase tracking-tight mt-0.5">{campaign.type} Sequence</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1.5 w-fit ${
                      campaign.status === 'active' ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 border border-emerald-100 dark:border-emerald-500/20' :
                      campaign.status === 'paused' ? 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 border border-amber-100 dark:border-amber-500/20' :
                      campaign.status === 'completed' ? 'bg-slate-100 dark:bg-white/10 text-slate-600 border border-slate-200 dark:border-white/10' :
                      'bg-slate-50 dark:bg-white/5 text-slate-400 border border-slate-200 dark:border-white/5'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        campaign.status === 'active' ? 'bg-emerald-500 animate-pulse' :
                        campaign.status === 'paused' ? 'bg-amber-500' :
                        campaign.status === 'completed' ? 'bg-slate-500' :
                        'bg-slate-300'
                      }`} />
                      {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-900 dark:text-white">{campaign.leadsCount}</span>
                      <span className="text-[10px] text-slate-400 dark:text-slate-500 font-medium">Prospects</span>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <div className="space-y-1.5 max-w-[120px]">
                      <div className="flex justify-between text-[10px] font-bold">
                        <span className="text-slate-400">Open Rate</span>
                        <span className="text-slate-900 dark:text-white">{campaign.openRate}%</span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden">
                        <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${campaign.openRate}%` }} />
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                      <Clock className="w-3 h-3" />
                      <span className="text-xs">{campaign.lastActive}</span>
                    </div>
                  </td>
                  <td className="px-6 py-5 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button 
                        onClick={() => toggleCampaignStatus(campaign.id)}
                        className={`p-2 rounded-lg transition-all ${
                          campaign.status === 'active' 
                            ? 'text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-500/10' 
                            : 'text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-500/10'
                        }`}
                        title={campaign.status === 'active' ? 'Pause' : 'Resume'}
                      >
                        {campaign.status === 'active' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      </button>
                      <button className="p-2 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-white/5 rounded-lg transition-all">
                        <BarChart3 className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5 rounded-lg transition-all">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* AI Suggestions Section */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        className="p-8 bg-indigo-900/40 rounded-[2rem] border border-indigo-500/20 relative overflow-hidden"
      >
        <div className="absolute right-0 top-0 p-10 opacity-10">
          <Sparkles className="w-40 h-40 text-indigo-400" />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
          <div className="w-20 h-20 bg-indigo-500 rounded-3xl flex items-center justify-center shadow-2xl shadow-indigo-500/40 shrink-0">
            <Sparkles className="w-10 h-10 text-white animate-pulse" />
          </div>
          <div className="flex-1 space-y-2 text-center md:text-left">
            <h4 className="text-xl font-bold text-white">AI Optimization Opportunity</h4>
            <p className="text-indigo-100/70 text-sm max-w-2xl">
              Your "Q1 Tech Startup Outreach" campaign is performing above average. We've identified <span className="text-indigo-300 font-bold">12 high-intent prospects</span> who opened your email twice but haven't clicked. Would you like to deploy a personalized follow-up?
            </p>
          </div>
          <button className="px-8 py-3 bg-white text-indigo-600 rounded-2xl text-sm font-bold shadow-xl hover:bg-indigo-50 transition-all hover:scale-[1.05]">
            Auto-Deploy Follow-up
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default CampaignView;
