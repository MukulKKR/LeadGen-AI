import React from 'react';
import { 
  Building2, 
  MapPin, 
  Globe, 
  Users, 
  UserCircle2, 
  Briefcase,
  Zap,
  TrendingUp,
  Target,
  Mail,
  BookmarkCheck,
  Bookmark,
  Sparkles,
  Lightbulb,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';
import { motion } from 'framer-motion';
import { Lead } from '../services/leadService';

interface EnrichmentPanelProps {
  lead: Lead;
  onGenerateOutreach: () => void;
  onSaveLead: (id: number) => void;
  onUnsaveLead: (id: number) => void;
}

const EnrichmentPanel: React.FC<EnrichmentPanelProps> = ({
  lead,
  onGenerateOutreach,
  onSaveLead,
  onUnsaveLead
}) => {
  return (
    <div className="space-y-10">
      {/* Lead Score & Conversion */}
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-slate-50 dark:bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-slate-100 dark:border-white/5 relative overflow-hidden group shadow-inner">
          <Target className="absolute -top-4 -right-4 w-20 h-20 text-indigo-500/[0.03] group-hover:text-indigo-500/[0.06] transition-all" />
          <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] mb-2">Lead Score</p>
          <div className="flex items-baseline gap-1.5">
            <span className="text-4xl font-bold text-slate-900 dark:text-white tracking-tight">{lead.leadScore}</span>
            <span className="text-sm font-bold text-slate-400 dark:text-slate-600">/ 100</span>
          </div>
        </div>
        
        <div className="bg-slate-50 dark:bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-slate-100 dark:border-white/5 relative overflow-hidden group shadow-inner">
          <Zap className="absolute -top-4 -right-4 w-20 h-20 text-emerald-500/[0.03] group-hover:text-emerald-500/[0.06] transition-all" />
          <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] mb-2">Conversion</p>
          <div className="flex items-baseline gap-1.5">
            <span className="text-4xl font-bold text-emerald-600 dark:text-emerald-400 tracking-tight">{lead.conversionProbability}%</span>
            <span className="text-sm font-bold text-slate-400 dark:text-slate-600">Prob.</span>
          </div>
        </div>
      </div>

      {/* Basic Info */}
      <section className="space-y-5">
        <div className="flex items-center justify-between px-2">
          <h4 className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] flex items-center gap-2.5">
            <Building2 className="w-4 h-4 text-indigo-500" />
            Company Intelligence
          </h4>
          <button 
            onClick={() => lead.isSaved ? onUnsaveLead(lead.id) : onSaveLead(lead.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[11px] font-bold transition-all ${lead.isSaved ? 'bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-400/20 shadow-sm' : 'bg-slate-50 dark:bg-white/5 text-slate-400 dark:text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10'}`}
          >
            {lead.isSaved ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
            {lead.isSaved ? 'Saved' : 'Save Lead'}
          </button>
        </div>
        
        <div className="bg-slate-50 dark:bg-white/5 backdrop-blur-md p-8 rounded-[2rem] border border-slate-100 dark:border-white/5 space-y-8 shadow-inner">
          <p className="text-sm text-slate-600 dark:text-slate-300 font-medium leading-relaxed italic border-l-3 border-indigo-500/30 dark:border-indigo-500/30 pl-6 py-1">
            "{lead.description}"
          </p>
          
          <div className="grid grid-cols-2 gap-8">
            <div className="space-y-2">
              <p className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">Industry</p>
              <div className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
                <div className="w-7 h-7 bg-indigo-50 dark:bg-indigo-500/10 rounded-lg flex items-center justify-center border border-indigo-100 dark:border-indigo-500/10">
                  <Briefcase className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                </div>
                {lead.industry}
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">Growth Potential</p>
              <div className={`text-sm font-bold flex items-center gap-2.5 ${lead.growthPotential === 'High' ? 'text-emerald-600 dark:text-emerald-400' : 'text-indigo-600 dark:text-indigo-400'}`}>
                <div className={`w-7 h-7 ${lead.growthPotential === 'High' ? 'bg-emerald-50 dark:bg-emerald-500/10 border-emerald-100 dark:border-emerald-500/10' : 'bg-indigo-50 dark:bg-indigo-500/10 border-indigo-100 dark:border-indigo-500/10'} rounded-lg flex items-center justify-center border`}>
                  <TrendingUp className={`w-3.5 h-3.5 ${lead.growthPotential === 'High' ? 'text-emerald-600 dark:text-emerald-400' : 'text-indigo-600 dark:text-indigo-400'}`} />
                </div>
                {lead.growthPotential}
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">Team Size</p>
              <div className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
                <div className="w-7 h-7 bg-white dark:bg-white/5 rounded-lg flex items-center justify-center border border-slate-100 dark:border-white/5">
                  <Users className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
                </div>
                {lead.companySize}
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">Decision Maker</p>
              <div className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
                <div className="w-7 h-7 bg-white dark:bg-white/5 rounded-lg flex items-center justify-center border border-slate-100 dark:border-white/5">
                  <UserCircle2 className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
                </div>
                {lead.targetRole}
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100 dark:border-white/5">
            <a 
              href={lead.website} 
              target="_blank" 
              rel="noreferrer"
              className="flex items-center justify-center gap-2.5 w-full py-4 bg-slate-50 dark:bg-white/5 text-slate-500 dark:text-slate-400 rounded-2xl text-[13px] font-bold hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 transition-all border border-slate-100 dark:border-white/5 shadow-sm"
            >
              <Globe className="w-4.5 h-4.5" />
              Explore Digital Presence
            </a>
          </div>
        </div>
      </section>

      {/* AI Analysis Cards */}
      <section className="space-y-5">
        <h4 className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] flex items-center gap-2.5 px-2">
          <Sparkles className="w-4 h-4 text-indigo-500" />
          AI Analysis
        </h4>
        
        <div className="grid grid-cols-1 gap-4">
          <div className="bg-indigo-50 dark:bg-indigo-500/[0.03] p-6 rounded-2xl border border-indigo-100 dark:border-indigo-500/10 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-5">
              <Lightbulb className="w-12 h-12" />
            </div>
            <div className="flex items-center gap-2.5 mb-3">
              <Lightbulb className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-[0.2em]">Outreach Hook</span>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
              {lead.aiInsights?.outreachAngle || `Focus on ${lead.industry} specific growth automation.`}
            </p>
          </div>

          <div className="bg-emerald-50 dark:bg-emerald-500/[0.03] p-6 rounded-2xl border border-emerald-100 dark:border-emerald-500/10 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-5">
              <CheckCircle2 className="w-12 h-12" />
            </div>
            <div className="flex items-center gap-2.5 mb-3">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-[0.2em]">AI Strategy</span>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
              {lead.outreachRecommendation?.strategy || "Multi-channel approach starting with personalized email."}
            </p>
          </div>
        </div>
      </section>

      <div className="pt-6">
        <motion.button 
          whileHover={{ scale: 1.02, translateY: -2, boxShadow: "0 20px 40px -10px rgba(79, 70, 229, 0.4)" }}
          whileTap={{ scale: 0.98 }}
          onClick={onGenerateOutreach}
          className="w-full py-5 glow-button text-white rounded-2xl text-[15px] font-bold flex items-center justify-center gap-3"
        >
          <Mail className="w-5.5 h-5.5" />
          Generate Outreach Campaign
          <ArrowRight className="w-4.5 h-4.5 opacity-60" />
        </motion.button>
      </div>
    </div>
  );
};

export default EnrichmentPanel;