import React, { useState } from 'react';
import { Sparkles, Bell, User, Settings, LogOut, Moon, Sun, ChevronDown, Search } from 'lucide-react';
import { useTheme } from '../lib/ThemeProvider';
import { toast } from 'sonner';
import { useUserProfile } from './hooks/useUserProfile';

const Header = () => {
  const { theme, toggleTheme } = useTheme();
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const { profile } = useUserProfile();

  const handleProfileClick = (action: string) => {
    toast.success(`${action} functionality coming soon!`);
    setIsProfileOpen(false);
  };

  const avatarUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(profile.fullName)}&background=4f46e5&color=fff`;

  return (
    <header className="sticky top-0 z-50 w-full bg-white/80 dark:bg-[#020617]/80 backdrop-blur-xl border-b border-slate-200 dark:border-white/5 transition-all">
      <div className="max-w-[1920px] mx-auto px-4 sm:px-6 lg:px-10">
        <div className="flex justify-between items-center h-16 gap-8">
          <div className="flex items-center gap-4 lg:hidden">
            <div className="w-9 h-9 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Sparkles className="w-4.5 h-4.5 text-white" />
            </div>
            <h1 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight leading-none">LeadGen <span className="text-indigo-600 dark:text-indigo-400">AI</span></h1>
          </div>

          <div className="hidden lg:flex items-center gap-2">
             <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">Workspace / <span className="text-indigo-600 dark:text-indigo-400">Dashboard</span></p>
          </div>

          {/* Global Search Bar */}
          <div className="flex-1 max-w-xl hidden md:block">
            <div className="relative group">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500 group-focus-within:text-indigo-600 dark:group-focus-within:text-indigo-400 transition-colors">
                <Search className="w-4 h-4" />
              </div>
              <input 
                type="text" 
                placeholder="Search leads, companies, campaigns..."
                className="w-full bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/5 focus:border-indigo-500/50 focus:bg-slate-200/50 dark:focus:bg-white/10 rounded-xl py-2.5 pl-11 pr-4 text-xs font-medium text-slate-900 dark:text-white transition-all outline-none placeholder:text-slate-400 dark:placeholder:text-slate-600"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    toast.info(`Searching for "${e.currentTarget.value}" across workspace...`);
                  }
                }}
              />
              <div className="absolute right-4 top-1/2 -translate-y-1/2 hidden lg:flex items-center gap-1.5 opacity-20 dark:opacity-20 group-focus-within:opacity-40 transition-opacity">
                <kbd className="px-1.5 py-0.5 bg-slate-300 dark:bg-white/10 rounded text-[9px] font-bold text-slate-600 dark:text-slate-400">⌘</kbd>
                <kbd className="px-1.5 py-0.5 bg-slate-300 dark:bg-white/10 rounded text-[9px] font-bold text-slate-600 dark:text-slate-400">K</kbd>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4 shrink-0">
            <button 
              onClick={toggleTheme}
              className="w-9 h-9 flex items-center justify-center text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5 rounded-xl transition-all"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            <button 
              onClick={() => toast.info('You have 3 new AI insights!')}
              className="w-9 h-9 flex items-center justify-center text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5 rounded-xl transition-all relative"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-2.5 right-2.5 w-1.5 h-1.5 bg-indigo-500 rounded-full shadow-[0_0_8px_rgba(79,70,229,0.5)]"></span>
            </button>

            <div className="relative">
              <button 
                onClick={() => setIsProfileOpen(!isProfileOpen)}
                className="flex items-center gap-2 p-1 rounded-xl hover:bg-slate-100 dark:hover:bg-white/5 transition-all group"
              >
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center overflow-hidden border border-slate-200 dark:border-white/5 transition-all">
                  <img src={avatarUrl} alt="User" className="w-full h-full object-cover" />
                </div>
                <ChevronDown className={`w-3 h-3 text-slate-400 dark:text-slate-500 transition-transform ${isProfileOpen ? 'rotate-180' : ''}`} />
              </button>

              {isProfileOpen && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setIsProfileOpen(false)}></div>
                  <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/5 rounded-2xl shadow-2xl z-20 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
                    <div className="p-5 border-b border-slate-100 dark:border-white/5 bg-slate-50 dark:bg-white/5">
                      <p className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Personal Account</p>
                      <p className="text-sm font-bold text-slate-900 dark:text-white mt-1">{profile.fullName}</p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">{profile.email}</p>
                    </div>
                    <div className="p-2">
                      <button 
                        onClick={() => handleProfileClick('My Profile')}
                        className="w-full flex items-center gap-3 px-3 py-2.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-white/5 rounded-xl transition-colors"
                      >
                        <User className="w-4 h-4 text-indigo-500 dark:text-indigo-400" />
                        My Profile
                      </button>
                      <button 
                        onClick={() => handleProfileClick('Settings')}
                        className="w-full flex items-center gap-3 px-3 py-2.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-white/5 rounded-xl transition-colors"
                      >
                        <Settings className="w-4 h-4 text-slate-400 dark:text-slate-500" />
                        Settings
                      </button>
                    </div>
                    <div className="p-2 border-t border-slate-100 dark:border-white/5">
                      <button 
                        onClick={() => {
                          localStorage.removeItem('user_profile');
                          window.location.reload();
                        }}
                        className="w-full flex items-center gap-3 px-3 py-2.5 text-xs font-bold text-rose-500 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-xl transition-colors"
                      >
                        <LogOut className="w-4 h-4" />
                        Log Out
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
