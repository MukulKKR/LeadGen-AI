import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  History, 
  Search, 
  Filter, 
  Calendar, 
  Trash2, 
  ArrowRight, 
  ExternalLink,
  Users,
  Building2,
  Mail,
  Target,
  Clock,
  Zap
} from 'lucide-react';
import { toast } from 'sonner';

interface HistoryItem {
  id: string;
  type: 'search' | 'outreach' | 'enrichment' | 'export';
  title: string;
  subtitle: string;
  timestamp: string;
  details: string;
}

const MOCK_HISTORY: HistoryItem[] = [
  { id: '1', type: 'search', title: 'Lead Discovery Run', subtitle: 'Software • Austin, TX', timestamp: '12 mins ago', details: 'Found 42 high-value prospects' },
  { id: '2', type: 'outreach', title: 'Personalized Email Sent', subtitle: 'Alex Rivera @ TechFlow', timestamp: '1 hour ago', details: 'Strategy: Value-based pitch' },
  { id: '3', type: 'enrichment', title: 'Deep Intelligence Enrichment', subtitle: 'Stripe, Inc.', timestamp: '3 hours ago', details: 'Analysis of recent funding and hiring' },
  { id: '4', type: 'export', title: 'Lead Export Completed', subtitle: 'Q1 Prospects List', timestamp: 'Yesterday', details: '150 leads exported to CSV' },
  { id: '5', type: 'search', title: 'Lead Discovery Run', subtitle: 'E-commerce • Remote', timestamp: 'Yesterday', details: 'Found 128 matching leads' },
  { id: '6', type: 'outreach', title: 'Campaign Deployment', subtitle: 'Enterprise SaaS Re-engagement', timestamp: '2 days ago', details: 'Deployed 1,200 emails' },
  { id: '7', type: 'enrichment', title: 'Bulk Enrichment', subtitle: '50 Leads Processed', timestamp: '3 days ago', details: 'AI Lead scoring updated for all' },
];

const HistoryView: React.FC = () => {
  const [history, setHistory] = useState<HistoryItem[]>(MOCK_HISTORY);
  const [filter, setFilter] = useState<'all' | 'search' | 'outreach' | 'enrichment'>('all');

  const filteredHistory = filter === 'all' ? history : history.filter(h => h.type === filter);

  const clearHistory = () => {
    setHistory([]);
    toast.success('Activity history cleared');
  };

  const deleteItem = (id: string) => {
    setHistory(prev => prev.filter(h => h.id !== id));
    toast.success('Activity removed');
  };

  return (
    <div className="space-y-8 pb-10">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-600/20">
            <History className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Activity Log</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">Track your AI discovery and outreach history</p>
          </div>
        </div>
        
        <button 
          onClick={clearHistory}
          className="flex items-center gap-2 px-4 py-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-xl text-xs font-bold transition-all border border-transparent hover:border-rose-100 dark:hover:border-rose-500/20"
        >
          <Trash2 className="w-4 h-4" />
          Clear Activity Log
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex p-1 bg-slate-100 dark:bg-white/5 rounded-2xl border border-slate-200 dark:border-white/10 w-fit">
        {['all', 'search', 'outreach', 'enrichment'].map((t) => (
          <button 
            key={t}
            onClick={() => setFilter(t as any)}
            className={`px-6 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all ${filter === t ? 'bg-white dark:bg-indigo-600 text-indigo-600 dark:text-white shadow-md' : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'}`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Timeline */}
      <div className="space-y-4">
        {filteredHistory.length === 0 ? (
          <div className="glass-panel p-20 flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-16 h-16 bg-slate-100 dark:bg-white/5 rounded-full flex items-center justify-center">
              <History className="w-8 h-8 text-slate-300" />
            </div>
            <p className="text-slate-500 font-medium">No activity history found</p>
          </div>
        ) : (
          filteredHistory.map((item, i) => (
            <motion.div 
              key={item.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className="glass-panel p-6 group hover:border-indigo-200 dark:hover:border-indigo-500/30 transition-all"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex items-start gap-5">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 border ${
                    item.type === 'search' ? 'bg-blue-50 dark:bg-blue-500/10 border-blue-100 dark:border-blue-500/20 text-blue-600' :
                    item.type === 'outreach' ? 'bg-emerald-50 dark:bg-emerald-500/10 border-emerald-100 dark:border-emerald-500/20 text-emerald-600' :
                    item.type === 'enrichment' ? 'bg-indigo-50 dark:bg-indigo-500/10 border-indigo-100 dark:border-indigo-500/20 text-indigo-600' :
                    'bg-slate-50 dark:bg-white/10 border-slate-200 dark:border-white/20 text-slate-600'
                  }`}>
                    {item.type === 'search' ? <Search className="w-6 h-6" /> :
                     item.type === 'outreach' ? <Mail className="w-6 h-6" /> :
                     item.type === 'enrichment' ? <Zap className="w-6 h-6" /> :
                     <ExternalLink className="w-6 h-6" />}
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-3">
                      <h4 className="text-base font-bold text-slate-900 dark:text-white">{item.title}</h4>
                      <span className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest flex items-center gap-1.5">
                        <Clock className="w-3 h-3" />
                        {item.timestamp}
                      </span>
                    </div>
                    <p className="text-sm text-slate-600 dark:text-slate-300 flex items-center gap-2">
                      {item.type === 'search' && <Building2 className="w-3.5 h-3.5" />}
                      {item.type === 'outreach' && <Users className="w-3.5 h-3.5" />}
                      {item.type === 'enrichment' && <Target className="w-3.5 h-3.5" />}
                      {item.subtitle}
                    </p>
                    <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">{item.details}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3 self-end md:self-center">
                  <button className="flex items-center gap-2 px-4 py-2 bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 text-slate-600 dark:text-slate-300 rounded-xl text-[10px] font-bold transition-all border border-slate-200 dark:border-white/10">
                    View Result
                    <ArrowRight className="w-3 h-3" />
                  </button>
                  <button 
                    onClick={() => deleteItem(item.id)}
                    className="p-2.5 text-slate-300 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-xl transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Analytics Insight */}
      <div className="p-8 border-2 border-dashed border-slate-200 dark:border-white/10 rounded-[2.5rem] flex flex-col md:flex-row items-center gap-8 justify-between text-center md:text-left">
        <div className="space-y-2">
          <h4 className="text-lg font-bold text-slate-900 dark:text-white">Monthly Productivity Summary</h4>
          <p className="text-slate-500 dark:text-slate-400 text-sm">
            You discovered <span className="text-indigo-600 font-bold">1,240 leads</span> and reached out to <span className="text-emerald-600 font-bold">450 prospects</span> this month.
          </p>
        </div>
        <button className="px-8 py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl text-xs font-bold shadow-xl transition-all hover:scale-[1.05]">
          Download Full Activity Report
        </button>
      </div>
    </div>
  );
};

export default HistoryView;
