import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  MapPin, 
  ArrowUpDown,
  Zap,
  Bookmark,
  BookmarkCheck,
  Flame,
  TrendingUp,
  ChevronRight,
  Search,
  UserCircle2,
  Save,
  MessageSquare,
  Eye
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lead } from '../services/leadService';
import { Skeleton } from './ui/Skeleton';

interface LeadTableProps {
  leads: Lead[];
  onSelectLead: (lead: Lead, mode?: 'enrich' | 'outreach') => void;
  selectedLeadId: number | null;
  onSaveLead: (id: number) => void;
  onUnsaveLead: (id: number) => void;
  isLoading?: boolean;
}

const TableSkeleton = () => (
  <>
    {[...Array(5)].map((_, i) => (
      <tr key={i} className="border-b border-gray-50 dark:border-white/5">
        <td className="px-8 py-5"><Skeleton className="w-8 h-8 rounded-lg" /></td>
        <td className="px-6 py-5">
          <div className="flex items-center gap-4">
            <Skeleton className="w-10 h-10 rounded-xl" />
            <div className="space-y-2">
              <Skeleton className="w-32 h-4" />
              <Skeleton className="w-24 h-3" />
            </div>
          </div>
        </td>
        <td className="px-6 py-5"><Skeleton className="w-24 h-4" /></td>
        <td className="px-6 py-5"><Skeleton className="w-20 h-4" /></td>
        <td className="px-6 py-5"><Skeleton className="w-24 h-6 rounded-md" /></td>
        <td className="px-8 py-5 text-right"><Skeleton className="w-5 h-5 ml-auto" /></td>
      </tr>
    ))}
  </>
);

type SortKey = 'leadScore' | 'companyName' | 'growthPotential' | 'conversionProbability';
type SortOrder = 'asc' | 'desc';

const LeadTable: React.FC<LeadTableProps> = ({ 
  leads, 
  onSelectLead, 
  selectedLeadId,
  onSaveLead,
  onUnsaveLead,
  isLoading = false
}) => {
  const [sortKey, setSortKey] = useState<SortKey>('leadScore');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortOrder('desc');
    }
  };

  const sortedLeads = useMemo(() => {
    return [...leads].sort((a, b) => {
      let comparison = 0;
      if (sortKey === 'leadScore') comparison = a.leadScore - b.leadScore;
      else if (sortKey === 'conversionProbability') comparison = a.conversionProbability - b.conversionProbability;
      else if (sortKey === 'companyName') comparison = a.companyName.localeCompare(b.companyName);
      else if (sortKey === 'growthPotential') {
        const priority = { High: 3, Moderate: 2, Steady: 1 };
        comparison = (priority[a.growthPotential] || 0) - (priority[b.growthPotential] || 0);
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });
  }, [leads, sortKey, sortOrder]);

  const getProbabilityColor = (prob: number) => {
    if (prob >= 75) return 'text-emerald-600 dark:text-emerald-400';
    if (prob >= 40) return 'text-indigo-600 dark:text-indigo-400';
    return 'text-rose-600 dark:text-rose-400';
  };

  return (
    <div className="w-full flex flex-col h-full bg-transparent">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse min-w-[1000px]">
          <thead>
            <tr className="border-b border-slate-100 dark:border-white/5">
              <th className="px-8 py-6 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] w-20">Save</th>
              <th 
                className="px-6 py-6 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] cursor-pointer hover:text-slate-900 dark:hover:text-white transition-colors"
                onClick={() => handleSort('companyName')}
              >
                <div className="flex items-center gap-2">
                  Company & Role
                  {sortKey === 'companyName' && <ArrowUpDown className="w-3.5 h-3.5 text-indigo-500" />}
                </div>
              </th>
              <th 
                className="px-6 py-6 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] cursor-pointer hover:text-slate-900 dark:hover:text-white transition-colors"
                onClick={() => handleSort('leadScore')}
              >
                <div className="flex items-center gap-2">
                  Score
                  {sortKey === 'leadScore' && <ArrowUpDown className="w-3.5 h-3.5 text-indigo-500" />}
                </div>
              </th>
              <th 
                className="px-6 py-6 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] cursor-pointer hover:text-slate-900 dark:hover:text-white transition-colors"
                onClick={() => handleSort('conversionProbability')}
              >
                <div className="flex items-center gap-2">
                  Conversion
                  {sortKey === 'conversionProbability' && <ArrowUpDown className="w-3.5 h-3.5 text-indigo-500" />}
                </div>
              </th>
              <th 
                className="px-6 py-6 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] cursor-pointer hover:text-slate-900 dark:hover:text-white transition-colors"
                onClick={() => handleSort('growthPotential')}
              >
                <div className="flex items-center gap-2">
                  Growth
                  {sortKey === 'growthPotential' && <ArrowUpDown className="w-3.5 h-3.5 text-indigo-500" />}
                </div>
              </th>
              <th className="px-8 py-6 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-white/5">
            <AnimatePresence mode="popLayout">
              {isLoading ? (
                <TableSkeleton />
              ) : sortedLeads.length === 0 ? (
                <motion.tr 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  key="empty"
                >
                  <td colSpan={6} className="px-8 py-32 text-center">
                    <div className="flex flex-col items-center justify-center">
                      <div className="w-20 h-20 bg-slate-50 dark:bg-white/5 rounded-[2.5rem] flex items-center justify-center mb-6 border border-slate-100 dark:border-white/5 shadow-inner">
                        <Search className="w-8 h-8 text-slate-300 dark:text-slate-700" />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">No prospects found</h3>
                      <p className="text-sm text-slate-500 mt-2 max-w-sm mx-auto font-medium">
                        Try adjusting filters or run a new search to discover high-value leads.
                      </p>
                    </div>
                  </td>
                </motion.tr>
              ) : (
                sortedLeads.map((lead) => (
                  <motion.tr 
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={lead.id} 
                    className={`group hover:bg-indigo-500/[0.04] dark:hover:bg-indigo-500/[0.03] transition-all cursor-pointer relative border-b border-slate-100 dark:border-white/5 ${selectedLeadId === lead.id ? 'bg-indigo-500/[0.06] dark:bg-indigo-500/[0.05]' : ''}`}
                    onClick={() => onSelectLead(lead)}
                  >
                    <td className="px-8 py-6" onClick={(e) => e.stopPropagation()}>
                      <button 
                        onClick={() => lead.isSaved ? onUnsaveLead(lead.id) : onSaveLead(lead.id)}
                        className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${lead.isSaved ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-400/10 border border-indigo-100 dark:border-indigo-400/20 shadow-sm' : 'text-slate-400 hover:text-indigo-600 dark:hover:text-white hover:bg-white dark:hover:bg-white/5'}`}
                      >
                        {lead.isSaved ? <BookmarkCheck className="w-4.5 h-4.5 fill-current" /> : <Bookmark className="w-4.5 h-4.5" />}
                      </button>
                    </td>
                    <td className="px-6 py-6">
                      <div className="flex items-center gap-4">
                        <div className="w-11 h-11 rounded-2xl bg-slate-50 dark:bg-white/5 flex items-center justify-center shrink-0 border border-slate-100 dark:border-white/5 group-hover:border-indigo-500/30 transition-all shadow-sm">
                          <Building2 className="w-5 h-5 text-slate-400 dark:text-slate-500 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-300 transition-colors">
                              {lead.companyName}
                            </span>
                            {lead.leadScore > 85 && (
                              <Flame className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
                            )}
                          </div>
                          <div className="flex items-center gap-3 mt-1.5 text-[11px] font-medium text-slate-500 dark:text-slate-400">
                            <span className="flex items-center gap-1.5"><MapPin className="w-3 h-3 text-indigo-500/60" /> {lead.location}</span>
                            <span className="flex items-center gap-1.5"><UserCircle2 className="w-3 h-3 text-indigo-500/60" /> {lead.targetRole}</span>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-6">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-1.5 bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${lead.leadScore}%` }}
                            className={`h-full ${lead.leadScore >= 80 ? 'bg-indigo-600 dark:bg-indigo-500' : 'bg-slate-300 dark:bg-slate-700'}`}
                          />
                        </div>
                        <span className={`text-xs font-bold ${lead.leadScore >= 80 ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400 dark:text-slate-500'}`}>
                          {lead.leadScore}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-6">
                      <div className="flex items-center gap-2.5">
                        <div className="relative w-6.5 h-6.5 shrink-0">
                          <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                            <circle className="text-slate-100 dark:text-white/5" strokeWidth="4" stroke="currentColor" fill="transparent" r="16" cx="18" cy="18" />
                            <circle
                              className={`${getProbabilityColor(lead.conversionProbability)} transition-all duration-1000 ease-out`}
                              strokeWidth="4"
                              strokeDasharray="100.5, 100.5"
                              strokeDashoffset={100.5 * (1 - lead.conversionProbability / 100)}
                              strokeLinecap="round"
                              stroke="currentColor"
                              fill="transparent"
                              r="16"
                              cx="18"
                              cy="18"
                            />
                          </svg>
                        </div>
                        <span className={`text-[11px] font-bold ${getProbabilityColor(lead.conversionProbability)}`}>{lead.conversionProbability}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-6">
                      {lead.growthPotential === 'High' ? (
                        <span className="inline-flex items-center gap-1.5 text-[9px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-400/10 px-2.5 py-1.5 rounded-lg border border-emerald-100 dark:border-emerald-400/20 uppercase tracking-[0.1em] shadow-[0_0_15px_rgba(52,211,153,0.1)]">
                          <TrendingUp className="w-3 h-3" /> High
                        </span>
                      ) : lead.growthPotential === 'Moderate' ? (
                        <span className="inline-flex items-center gap-1.5 text-[9px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-400/10 px-2.5 py-1.5 rounded-lg border border-indigo-100 dark:border-indigo-400/20 uppercase tracking-[0.1em] shadow-[0_0_15px_rgba(129,140,248,0.1)]">
                          <Zap className="w-3 h-3" /> Scaling
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 text-[9px] font-bold text-slate-500 bg-slate-50 dark:bg-white/5 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-white/5 uppercase tracking-[0.1em]">
                          Steady
                        </span>
                      )}
                    </td>
                    <td className="px-8 py-6 text-right relative">
                      <div className="flex items-center justify-end gap-2.5 opacity-0 group-hover:opacity-100 transition-all absolute right-12 top-1/2 -translate-y-1/2">
                        <button 
                          className="p-2.5 bg-white dark:bg-white/5 hover:bg-slate-50 dark:hover:bg-white/10 rounded-xl transition-all text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 border border-slate-200 dark:border-white/5 shadow-sm"
                          onClick={(e) => { e.stopPropagation(); lead.isSaved ? onUnsaveLead(lead.id) : onSaveLead(lead.id); }}
                          title="Save Lead"
                        >
                          <Save className="w-4 h-4" />
                        </button>
                        <button 
                          className="p-2.5 bg-white dark:bg-white/5 hover:bg-slate-50 dark:hover:bg-white/10 rounded-xl transition-all text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 border border-slate-200 dark:border-white/5 shadow-sm"
                          onClick={(e) => { e.stopPropagation(); onSelectLead(lead, 'outreach'); }}
                          title="Generate Outreach"
                        >
                          <MessageSquare className="w-4 h-4" />
                        </button>
                        <button 
                          className="p-2.5 bg-white dark:bg-white/5 hover:bg-slate-50 dark:hover:bg-white/10 rounded-xl transition-all text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 border border-slate-200 dark:border-white/5 shadow-sm"
                          onClick={(e) => { e.stopPropagation(); onSelectLead(lead, 'enrich'); }}
                          title="View Company"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>
                      <ChevronRight className="w-5 h-5 text-slate-300 dark:text-slate-700 group-hover:text-slate-900 dark:group-hover:text-white transition-all ml-auto group-hover:translate-x-1" />
                    </td>
                  </motion.tr>
                ))
              )}
            </AnimatePresence>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default LeadTable;

