import React, { useState } from 'react';
import { Search, MapPin, Briefcase, UserCircle2, Sparkles, Filter, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

interface SearchFormProps {
  onSearch: (query: { industry: string; location: string; role: string }) => void;
  isLoading: boolean;
}

const SearchForm: React.FC<SearchFormProps> = ({ onSearch, isLoading }) => {
  const [industry, setIndustry] = useState('');
  const [location, setLocation] = useState('');
  const [role, setRole] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch({ industry, location, role });
  };

  return (
    <div className="relative overflow-hidden group">
      <div className="flex items-center justify-between mb-10 relative z-10">
        <div className="flex items-center gap-5">
          <div className="w-14 h-14 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center border border-indigo-100 dark:border-indigo-500/20 shadow-inner relative">
            {isLoading ? (
              <Loader2 className="w-7 h-7 animate-spin" />
            ) : (
              <Filter className="w-7 h-7" />
            )}
            {isLoading && (
              <motion.div 
                layoutId="loader-glow"
                className="absolute inset-0 rounded-2xl bg-indigo-500/20 animate-pulse"
              />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">AI Lead Discovery</h3>
              {isLoading && (
                <motion.span 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="text-[10px] font-bold text-indigo-500 uppercase tracking-widest bg-indigo-50 dark:bg-indigo-500/10 px-2 py-0.5 rounded"
                >
                  Searching...
                </motion.span>
              )}
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1.5 font-medium">Find high-value B2B prospects using AI-powered discovery.</p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6 items-end relative z-10">
        <div className="space-y-3">
          <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">Industry</label>
          <div className="relative">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500 transition-colors group-focus-within:text-indigo-600 dark:group-focus-within:text-indigo-400">
              <Briefcase className="w-4.5 h-4.5" />
            </div>
            <input 
              type="text" 
              placeholder="SaaS, Fintech, AI..."
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
              className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/5 rounded-2xl py-4.5 pl-12 pr-4 text-sm font-medium text-slate-900 dark:text-white focus:outline-none focus:border-indigo-500/50 focus:bg-white dark:focus:bg-white/10 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600 shadow-sm"
            />
          </div>
        </div>

        <div className="space-y-3">
          <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">Location</label>
          <div className="relative">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500 transition-colors group-focus-within:text-indigo-600 dark:group-focus-within:text-indigo-400">
              <MapPin className="w-4.5 h-4.5" />
            </div>
            <input 
              type="text" 
              placeholder="United States, Europe..."
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/5 rounded-2xl py-4.5 pl-12 pr-4 text-sm font-medium text-slate-900 dark:text-white focus:outline-none focus:border-indigo-500/50 focus:bg-white dark:focus:bg-white/10 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600 shadow-sm"
            />
          </div>
        </div>

        <div className="space-y-3">
          <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">Target Role</label>
          <div className="relative">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500 transition-colors group-focus-within:text-indigo-600 dark:group-focus-within:text-indigo-400">
              <UserCircle2 className="w-4.5 h-4.5" />
            </div>
            <input 
              type="text" 
              placeholder="Founder, CEO, CTO..."
              value={role}
              onChange={(e) => setRole(e.target.value)}
              className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/5 rounded-2xl py-4.5 pl-12 pr-4 text-sm font-medium text-slate-900 dark:text-white focus:outline-none focus:border-indigo-500/50 focus:bg-white dark:focus:bg-white/10 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600 shadow-sm"
            />
          </div>
        </div>

        <motion.button 
          whileHover={{ scale: 1.02, translateY: -2, boxShadow: "0 20px 40px -10px rgba(79, 70, 229, 0.4)" }}
          whileTap={{ scale: 0.98 }}
          type="submit"
          disabled={isLoading}
          className="w-full py-4.5 glow-button text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-2.5 transition-all disabled:opacity-50"
        >
          {isLoading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            <>
              <Search className="w-5 h-5" />
              Find Leads
            </>
          )}
        </motion.button>
      </form>
    </div>
  );
};

export default SearchForm;