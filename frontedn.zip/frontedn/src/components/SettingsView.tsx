import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, 
  Bell, 
  Shield, 
  Zap, 
  Brain, 
  Globe, 
  Database, 
  CreditCard, 
  Users, 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  ChevronRight, 
  Save, 
  CheckCircle2, 
  AlertCircle,
  Settings as SettingsIcon,
  Sparkles,
  Link as LinkIcon,
  MessageSquare,
  Search,
  Bot
} from 'lucide-react';
import { toast } from 'sonner';
import { useUserProfile } from './hooks/useUserProfile';

const SettingsView: React.FC = () => {
  const [activeSection, setActiveSection] = useState<'profile' | 'notifications' | 'ai' | 'integrations' | 'billing'>('profile');
  const [isSaving, setIsSaving] = useState(false);
  const { profile, updateProfile } = useUserProfile();
  
  // Local state for form inputs
  const [formData, setFormData] = useState(profile);

  // Update local state when profile changes
  useEffect(() => {
    setFormData(profile);
  }, [profile]);

  const handleSave = () => {
    setIsSaving(true);
    // Simulate API call
    setTimeout(() => {
      updateProfile(formData);
      setIsSaving(false);
      toast.success('Settings saved successfully');
    }, 1500);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      if (name.includes('.')) {
        const [parent, child] = name.split('.');
        setFormData(prev => ({
          ...prev,
          [parent]: {
            ...(prev[parent as keyof typeof prev] as any),
            [child]: checked
          }
        }));
      }
    } else {
      if (name.includes('.')) {
        const [parent, child] = name.split('.');
        setFormData(prev => ({
          ...prev,
          [parent]: {
            ...(prev[parent as keyof typeof prev] as any),
            [child]: value
          }
        }));
      } else {
        setFormData(prev => ({ ...prev, [name]: value }));
      }
    }
  };

  const toggleNotification = (key: keyof typeof profile.notifications) => {
    setFormData(prev => ({
      ...prev,
      notifications: {
        ...prev.notifications,
        [key]: !prev.notifications[key]
      }
    }));
  };

  const toggleAiPref = (key: keyof typeof profile.aiPreferences) => {
    setFormData(prev => {
      const currentVal = prev.aiPreferences[key];
      if (typeof currentVal === 'boolean') {
        return {
          ...prev,
          aiPreferences: {
            ...prev.aiPreferences,
            [key]: !currentVal
          }
        };
      }
      return prev;
    });
  };

  const sections = [
    { id: 'profile', label: 'Profile', icon: User, description: 'Manage your personal information and account security' },
    { id: 'ai', label: 'AI Preferences', icon: Brain, description: 'Configure AI models and lead scoring algorithms' },
    { id: 'notifications', label: 'Notifications', icon: Bell, description: 'Control how you receive alerts and updates' },
    { id: 'integrations', label: 'Integrations', icon: LinkIcon, description: 'Connect with CRM and marketing tools' },
    { id: 'billing', label: 'Billing & Plan', icon: CreditCard, description: 'Manage your subscription and payment methods' },
  ];

  return (
    <div className="space-y-8 pb-10">
      {/* Settings Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-600/20">
            <SettingsIcon className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">System Configuration</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">Manage your account settings and AI workspace preferences</p>
          </div>
        </div>
        
        <button 
          onClick={handleSave}
          disabled={isSaving}
          className="flex items-center gap-2 px-6 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/20 hover:bg-indigo-500 transition-all disabled:opacity-70 disabled:cursor-not-allowed"
        >
          {isSaving ? (
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            >
              <Zap className="w-4 h-4" />
            </motion.div>
          ) : (
            <Save className="w-4 h-4" />
          )}
          {isSaving ? 'Saving Changes...' : 'Save Configuration'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Settings Navigation */}
        <div className="lg:col-span-1 space-y-2">
          {sections.map((section) => (
            <button
              key={section.id}
              onClick={() => setActiveSection(section.id as any)}
              className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-all hover:scale-[1.01] active:scale-[0.99] ${
                activeSection === section.id 
                  ? 'bg-white dark:bg-white/10 border-indigo-200 dark:border-indigo-500/30 shadow-md hover:shadow-lg' 
                  : 'bg-transparent border-transparent hover:bg-slate-100 dark:hover:bg-white/5 text-slate-500 hover:shadow-sm'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${
                  activeSection === section.id 
                    ? 'bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400' 
                    : 'bg-slate-100 dark:bg-white/5 text-slate-400'
                }`}>
                  <section.icon className="w-4 h-4" />
                </div>
                <span className={`text-xs font-bold uppercase tracking-wider ${
                  activeSection === section.id ? 'text-slate-900 dark:text-white' : ''
                }`}>
                  {section.label}
                </span>
              </div>
              {activeSection === section.id && (
                <motion.div layoutId="active-indicator">
                  <ChevronRight className="w-4 h-4 text-indigo-500" />
                </motion.div>
              )}
            </button>
          ))}
        </div>

        {/* Settings Content */}
        <div className="lg:col-span-3">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2 }}
              className="glass-panel p-8"
            >
              {activeSection === 'profile' && (
                <div className="space-y-8">
                  <div className="flex items-center gap-4">
                    <div className="relative group">
                      <div className="w-20 h-20 rounded-3xl bg-indigo-50 dark:bg-indigo-500/10 flex items-center justify-center border-2 border-dashed border-indigo-200 dark:border-indigo-500/30 group-hover:border-indigo-500 transition-colors cursor-pointer">
                        <User className="w-8 h-8 text-indigo-500" />
                      </div>
                      <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg border-2 border-white dark:border-slate-900 cursor-pointer">
                        <Sparkles className="w-3 h-3 text-white" />
                      </div>
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-slate-900 dark:text-white">Profile Identity</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Update your account details and public profile</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest px-1">Full Name</label>
                      <input 
                        type="text" 
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleInputChange}
                        className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm font-medium focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all outline-none text-slate-900 dark:text-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest px-1">Job Title</label>
                      <input 
                        type="text" 
                        name="jobTitle"
                        value={formData.jobTitle}
                        onChange={handleInputChange}
                        className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm font-medium focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all outline-none text-slate-900 dark:text-white"
                      />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest px-1">Email Address</label>
                      <div className="relative">
                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <input 
                          type="email" 
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl pl-11 pr-4 py-3 text-sm font-medium focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all outline-none text-slate-900 dark:text-white"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-slate-100 dark:border-white/5">
                    <h5 className="text-xs font-bold text-slate-900 dark:text-white mb-4 uppercase tracking-wider">Security Access</h5>
                    <button 
                      onClick={() => toast.info('Password reset link sent to your email')}
                      className="flex items-center gap-3 px-4 py-2.5 bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 rounded-xl text-xs font-bold transition-all border border-slate-200 dark:border-white/10"
                    >
                      <Lock className="w-4 h-4 text-indigo-500" />
                      Change Password
                    </button>
                  </div>
                </div>
              )}

              {activeSection === 'ai' && (
                <div className="space-y-8">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-indigo-50 dark:bg-indigo-500/10 rounded-2xl border border-indigo-100 dark:border-indigo-500/20">
                      <Brain className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-slate-900 dark:text-white">AI Engine Configuration</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Optimize lead discovery and message generation models</p>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="p-5 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5 flex items-center justify-between">
                      <div className="space-y-1">
                        <p className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                          High-Fidelity Lead Scoring
                          <span className="px-1.5 py-0.5 bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 text-[8px] font-bold rounded">BETA</span>
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">Use deep analysis for more accurate conversion probability</p>
                      </div>
                      <div className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          className="sr-only peer" 
                          checked={formData.aiPreferences.highFidelityScoring}
                          onChange={() => toggleAiPref('highFidelityScoring')}
                        />
                        <div className="w-11 h-6 bg-slate-200 dark:bg-white/10 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                      </div>
                    </div>

                    <div className="p-5 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5 flex items-center justify-between">
                      <div className="space-y-1">
                        <p className="text-sm font-bold text-slate-900 dark:text-white">Autonomous Personalization</p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">AI automatically researches prospect news for outreach messages</p>
                      </div>
                      <div className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          className="sr-only peer" 
                          checked={formData.aiPreferences.autonomousPersonalization}
                          onChange={() => toggleAiPref('autonomousPersonalization')}
                        />
                        <div className="w-11 h-6 bg-slate-200 dark:bg-white/10 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest px-1">Intelligence Model</label>
                      <select 
                        name="aiPreferences.intelligenceModel"
                        value={formData.aiPreferences.intelligenceModel}
                        onChange={handleInputChange}
                        className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl px-4 py-3 text-sm font-medium focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all outline-none text-slate-900 dark:text-white appearance-none cursor-pointer"
                      >
                        <option value="gpt4">LeadGen Turbo-4 (Balanced)</option>
                        <option value="gpt4o">LeadGen Ultra-Omni (High Detail)</option>
                        <option value="claude">LeadGen Creative-3 (Better Outreach)</option>
                      </select>
                    </div>

                    <div className="p-4 bg-indigo-50 dark:bg-indigo-500/5 rounded-xl border border-indigo-100 dark:border-indigo-500/10 flex items-start gap-3">
                      <Bot className="w-5 h-5 text-indigo-600 dark:text-indigo-400 mt-0.5" />
                      <p className="text-[11px] text-indigo-600/80 dark:text-indigo-400/80 leading-relaxed font-medium">
                        Increasing the model intelligence may result in slightly longer discovery times but will significantly improve lead score accuracy and message resonance.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {activeSection === 'notifications' && (
                <div className="space-y-8">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-indigo-50 dark:bg-indigo-500/10 rounded-2xl border border-indigo-100 dark:border-indigo-500/20">
                      <Bell className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-slate-900 dark:text-white">Communication Relay</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Stay updated on new lead discoveries and campaign results</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {[
                      { id: 'highValueLead', title: 'New High-Value Lead', desc: 'Alert when a prospect with score > 90 is found' },
                      { id: 'weeklyReport', title: 'Weekly Performance Report', desc: 'Summary of pipeline growth and outreach results' },
                      { id: 'campaignThresholds', title: 'Campaign Thresholds', desc: 'Notify when outreach limits are reached' },
                      { id: 'aiUpdates', title: 'AI Discovery Updates', desc: 'News about new discovery algorithms' }
                    ].map((item, i) => (
                      <div key={i} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5">
                        <div className="space-y-1">
                          <p className="text-sm font-bold text-slate-900 dark:text-white">{item.title}</p>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">{item.desc}</p>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="flex flex-col items-center gap-1">
                            <span className="text-[8px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-tighter">Status</span>
                            <input 
                              type="checkbox" 
                              className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer" 
                              checked={formData.notifications[item.id as keyof typeof formData.notifications]} 
                              onChange={() => toggleNotification(item.id as any)}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeSection === 'integrations' && (
                <div className="space-y-8">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-indigo-50 dark:bg-indigo-500/10 rounded-2xl border border-indigo-100 dark:border-indigo-500/20">
                      <LinkIcon className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-slate-900 dark:text-white">Connected Ecosystem</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Sync lead data with your existing sales and marketing stack</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[
                      { name: 'Salesforce', status: 'connected', icon: '☁️' },
                      { name: 'HubSpot', status: 'connected', icon: '🧡' },
                      { name: 'Slack', status: 'not_connected', icon: '💬' },
                      { name: 'LinkedIn', status: 'not_connected', icon: '🔗' },
                      { name: 'Pipedrive', status: 'not_connected', icon: '📊' },
                      { name: 'Zapier', status: 'not_connected', icon: '⚡' }
                    ].map((app, i) => (
                      <div key={i} className="p-5 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5 group hover:border-indigo-200 dark:hover:border-indigo-500/30 transition-all">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-white dark:bg-white/10 flex items-center justify-center text-xl shadow-sm border border-slate-100 dark:border-white/5">
                              {app.icon}
                            </div>
                            <span className="text-sm font-bold text-slate-900 dark:text-white">{app.name}</span>
                          </div>
                          {app.status === 'connected' ? (
                            <span className="px-2 py-0.5 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[9px] font-bold rounded-full border border-emerald-100 dark:border-emerald-500/20 flex items-center gap-1">
                              <CheckCircle2 className="w-2.5 h-2.5" />
                              Active
                            </span>
                          ) : (
                            <button 
                              onClick={() => toast.success(`Connecting to ${app.name}...`)}
                              className="text-[9px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
                            >
                              Connect
                            </button>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400">
                          {app.status === 'connected' ? `Synced 12 minutes ago` : `Connect to sync your discovered leads automatically`}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeSection === 'billing' && (
                <div className="space-y-8">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-indigo-50 dark:bg-indigo-500/10 rounded-2xl border border-indigo-100 dark:border-indigo-500/20">
                      <CreditCard className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-slate-900 dark:text-white">Subscription Lifecycle</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Manage your enterprise plan and usage limits</p>
                    </div>
                  </div>

                  <div className="p-6 bg-gradient-to-br from-indigo-600 to-blue-700 rounded-[2rem] text-white shadow-xl shadow-indigo-600/20 relative overflow-hidden group">
                    <div className="absolute -right-10 -top-10 w-40 h-40 bg-white/10 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-700" />
                    <div className="relative z-10 space-y-6">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-[10px] font-bold uppercase tracking-widest opacity-70">Current Plan</p>
                          <h4 className="text-2xl font-bold mt-1">Enterprise AI Plus</h4>
                        </div>
                        <span className="px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-[10px] font-bold">Annual Billing</span>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between items-end">
                          <span className="text-xs font-medium opacity-80">Discovery Credits Used</span>
                          <span className="text-xs font-bold">8,450 / 10,000</span>
                        </div>
                        <div className="h-2 w-full bg-white/20 rounded-full overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: '84.5%' }}
                            transition={{ duration: 1, delay: 0.5 }}
                            className="h-full bg-white rounded-full"
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-4">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          <span className="text-[11px] font-bold">Renews on Oct 12, 2026</span>
                        </div>
                        <button 
                          onClick={() => toast.info('Redirecting to plan management...')}
                          className="px-4 py-2 bg-white text-indigo-600 rounded-xl text-xs font-bold hover:bg-slate-50 transition-colors shadow-lg"
                        >
                          Upgrade Plan
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h5 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Payment Method</h5>
                    <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-8 bg-slate-200 dark:bg-white/10 rounded-lg flex items-center justify-center font-bold text-[10px] border border-slate-300 dark:border-white/10 italic">
                          VISA
                        </div>
                        <div>
                          <p className="text-sm font-bold text-slate-900 dark:text-white">•••• •••• •••• 4242</p>
                          <p className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-bold tracking-widest">Expires 12/28</p>
                        </div>
                      </div>
                      <button 
                        onClick={() => toast.info('Opening payment method portal...')}
                        className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
                      >
                        Update
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default SettingsView;