import React from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Search, 
  Save, 
  History, 
  Settings, 
  Zap, 
  BarChart3, 
  Globe,
  PieChart,
  Target,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { motion } from 'framer-motion';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: any) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'search', label: 'Discovery', icon: Search },
    { id: 'saved', label: 'Saved Leads', icon: Save },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'campaigns', label: 'Campaigns', icon: Target },
    { id: 'history', label: 'History', icon: History },
  ];

  const secondaryItems = [
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'api', label: 'API Keys', icon: Zap },
  ];

  return (
    <aside className="w-64 h-screen sticky top-0 bg-[#020617] border-r border-white/5 flex flex-col z-40">
      <div className="p-6 pb-4">
        <div className="flex items-center gap-3 px-2 mb-10">
          <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white tracking-tight leading-none">LeadGen <span className="text-indigo-400">AI</span></h1>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1.5">v2.4.0 • Enterprise</p>
          </div>
        </div>

        <nav className="space-y-1.5">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] px-3 mb-4">Main Navigation</p>
          {menuItems.map((item) => {
            const isActive = activeTab === item.id || (activeTab === 'search' && item.id === 'search') || (activeTab === 'saved' && item.id === 'saved');
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all group ${
                  isActive 
                    ? 'bg-indigo-500/10 text-indigo-400 shadow-sm border border-indigo-500/20' 
                    : 'text-slate-400 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <item.icon className={`w-5 h-5 transition-colors ${isActive ? 'text-indigo-400' : 'text-slate-500 group-hover:text-white'}`} />
                  <span className="text-xs font-bold tracking-tight">{item.label}</span>
                </div>
                {isActive && <motion.div layoutId="activeDot" className="w-1.5 h-1.5 rounded-full bg-indigo-400" />}
              </button>
            );
          })}
        </nav>
      </div>

      <div className="mt-auto p-8 pt-4 space-y-6">
        <div>
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] px-3 mb-4">Support & Tools</p>
          <nav className="space-y-1.5">
            {secondaryItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all group ${
                  activeTab === item.id 
                    ? 'bg-indigo-500/10 text-indigo-400 shadow-sm border border-indigo-500/20' 
                    : 'text-slate-400 hover:bg-white/5 hover:text-white'
                }`}
              >
                <item.icon className={`w-5 h-5 transition-colors ${activeTab === item.id ? 'text-indigo-400' : 'text-slate-500 group-hover:text-white'}`} />
                <span className="text-xs font-bold tracking-tight">{item.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="p-5 bg-indigo-900/40 rounded-2xl border border-indigo-500/20 relative overflow-hidden group">
          <div className="relative z-10">
            <p className="text-[10px] font-bold text-indigo-100 uppercase tracking-[0.15em]">Subscription</p>
            <h4 className="text-sm font-bold text-white mt-1">Growth Plan</h4>
            <div className="mt-4 flex items-center justify-between">
              <span className="text-[10px] font-bold text-indigo-200">2,450 / 5,000 credits</span>
              <span className="text-[10px] font-bold text-white">49%</span>
            </div>
            <div className="mt-2 h-1.5 w-full bg-white/20 rounded-full overflow-hidden">
              <div className="h-full bg-white rounded-full w-[49%]" />
            </div>
            <button 
              onClick={() => setActiveTab('settings')}
              className="mt-4 w-full py-2 bg-white text-indigo-600 rounded-lg text-[10px] font-bold flex items-center justify-center gap-2 hover:bg-indigo-50 transition-colors"
            >
              Upgrade Now
              <ChevronRight className="w-3 h-3" />
            </button>
          </div>
          <div className="absolute -right-4 -bottom-4 w-20 h-20 bg-white/5 rounded-full blur-2xl group-hover:bg-white/10 transition-all"></div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
