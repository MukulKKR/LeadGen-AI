import { useState, useEffect } from 'react';
import { userService, UserProfile } from '../../services/userService';

export const useUserProfile = () => {
  const [profile, setProfile] = useState<UserProfile>(userService.getProfile());

  useEffect(() => {
    const handleUpdate = () => {
      setProfile(userService.getProfile());
    };

    window.addEventListener('user-profile-updated', handleUpdate);
    window.addEventListener('storage', (e) => {
      if (e.key === 'user_profile') {
        handleUpdate();
      }
    });

    return () => {
      window.removeEventListener('user-profile-updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, []);

  const updateProfile = (newProfile: UserProfile) => {
    userService.updateProfile(newProfile);
    setProfile(newProfile);
  };

  return { profile, updateProfile };
};
