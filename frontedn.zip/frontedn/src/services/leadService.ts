import api from '../lib/api';

export interface Lead {
  id: number;
  companyName: string;
  industry: string;
  location: string;
  website: string;
  leadScore: number;
  conversionProbability: number;
  growthPotential: 'High' | 'Moderate' | 'Steady';
  description: string;
  companySize: string;
  targetRole: string;
  contactPerson: string;
  isSaved?: boolean;
  aiInsights?: {
    whyGoodTarget: string;
    painPoints: string;
    outreachAngle: string;
    dealPotential: string;
  };
  outreachRecommendation?: {
    strategy: string;
    bestDay: string;
    bestChannel: string;
  };
}

export interface DashboardStats {
  totalLeads: number;
  avgLeadScore: number;
  savedLeads: number;
  aiMessagesGenerated: number;
  probabilityDistribution: {
    high: number;
    medium: number;
    low: number;
  };
  aiInsights: {
    bestIndustry: string;
    topScoringLead: string;
    recommendedTime: string;
  };
}

export interface OutreachResponse {
  subject: string;
  body: string;
}

export interface AnalysisResponse {
  insights: string;
  outreachStrategy: string;
  talkingPoints: string[];
  pitchAngle: string;
}

export const leadService = {
  searchLeads: async (query: { 
    industry?: string; 
    location?: string; 
    role?: string; 
    sortBy?: string; 
    sortOrder?: 'asc' | 'desc';
    page?: number;
    limit?: number;
  }, signal?: AbortSignal): Promise<Lead[]> => {
    const params = new URLSearchParams();
    if (query.industry) params.append('industry', query.industry);
    if (query.location) params.append('location', query.location);
    if (query.role) params.append('targetRole', query.role);
    if (query.sortBy) params.append('sortBy', query.sortBy);
    if (query.sortOrder) params.append('sortOrder', query.sortOrder);
    if (query.page) params.append('page', query.page.toString());
    if (query.limit) params.append('limit', query.limit.toString());
    
    // Request only needed fields for the UI
    params.append('fields', 'id,companyName,industry,location,leadScore,targetRole,conversionProbability,growthPotential,isSaved');

    const response = await api.get(`/leads/search?${params.toString()}`, { signal });
    return response.data;
  },

  getStats: async (): Promise<DashboardStats> => {
    const response = await api.get('/leads/stats');
    return response.data;
  },

  getLeadDetails: async (id: number): Promise<Lead> => {
    const response = await api.get(`/leads/${id}/enrich`);
    return response.data;
  },

  saveLead: async (id: number) => {
    const response = await api.post(`/leads/${id}/save`);
    return response.data;
  },

  unsaveLead: async (id: number) => {
    const response = await api.delete(`/leads/${id}/save`);
    return response.data;
  },

  getSavedLeads: async () => {
    const response = await api.get('/leads/saved');
    return response.data;
  },

  generateOutreach: async (lead: Partial<Lead>): Promise<OutreachResponse> => {
    const response = await api.post('/ai/generate-outreach', {
      companyName: lead.companyName,
      industry: lead.industry,
      targetRole: lead.targetRole
    });
    return response.data;
  },

  analyzeLead: async (lead: Lead): Promise<AnalysisResponse> => {
    const response = await api.post('/ai/analyze', {
      companyName: lead.companyName,
      industry: lead.industry,
      description: lead.description,
      targetRole: lead.targetRole
    });
    return response.data;
  }
};