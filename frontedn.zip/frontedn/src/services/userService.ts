export interface UserProfile {
  fullName: string;
  jobTitle: string;
  email: string;
  notifications: {
    highValueLead: boolean;
    weeklyReport: boolean;
    campaignThresholds: boolean;
    aiUpdates: boolean;
  };
  aiPreferences: {
    highFidelityScoring: boolean;
    autonomousPersonalization: boolean;
    intelligenceModel: string;
  };
}

const DEFAULT_PROFILE: UserProfile = {
  fullName: 'Alex Rivera',
  jobTitle: 'Head of Sales',
  email: 'alex@leadgenai.com',
  notifications: {
    highValueLead: true,
    weeklyReport: true,
    campaignThresholds: true,
    aiUpdates: false,
  },
  aiPreferences: {
    highFidelityScoring: true,
    autonomousPersonalization: true,
    intelligenceModel: 'gpt4',
  }
};

const STORAGE_KEY = 'user_profile';

export const userService = {
  getProfile: (): UserProfile => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        // Merge with defaults to handle migrations
        return {
          ...DEFAULT_PROFILE,
          ...parsed,
          notifications: { ...DEFAULT_PROFILE.notifications, ...(parsed.notifications || {}) },
          aiPreferences: { ...DEFAULT_PROFILE.aiPreferences, ...(parsed.aiPreferences || {}) }
        };
      } catch (e) {
        return DEFAULT_PROFILE;
      }
    }
    return DEFAULT_PROFILE;
  },
  updateProfile: (profile: UserProfile) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
    window.dispatchEvent(new Event('user-profile-updated'));
  }
};